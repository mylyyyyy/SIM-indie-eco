<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-black text-slate-800">Manajemen Tim</h2>
        <a href="<?php echo e(route('admin.teams.create')); ?>" class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-lg flex items-center gap-2">
            <i class="fas fa-plus"></i> Tambah Anggota
        </a>
    </div>

    
    <?php if(session('success')): ?>
        <script>Swal.fire({ icon: 'success', title: 'Berhasil', text: "<?php echo e(session('success')); ?>", timer: 2000, showConfirmButton: false });</script>
    <?php endif; ?>

    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm text-slate-600">
                <thead class="bg-slate-50 border-b border-slate-200 text-xs uppercase text-slate-500 font-bold">
                    <tr>
                        <th class="px-6 py-4">No</th>
                        <th class="px-6 py-4">Foto</th>
                        <th class="px-6 py-4">Nama & Jabatan</th>
                        <th class="px-6 py-4">Kontak</th>
                        <th class="px-6 py-4 text-center">Urutan</th>
                        <th class="px-6 py-4 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-slate-50 transition-colors">
                        <td class="px-6 py-4"><?php echo e($index + 1); ?></td>
                        <td class="px-6 py-4">
                            <?php if($team->photo): ?>
                                <img src="<?php echo e($team->photo); ?>" alt="<?php echo e($team->name); ?>" class="w-12 h-12 rounded-full object-cover border border-slate-200 shadow-sm">
                            <?php else: ?>
                                <div class="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 font-bold text-xs border border-slate-200">
                                    No Pic
                                </div>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4">
                            <div class="font-bold text-slate-800 text-base"><?php echo e($team->name); ?></div>
                            <div class="text-xs text-blue-600 font-bold uppercase tracking-wide"><?php echo e($team->role); ?></div>
                        </td>
                        <td class="px-6 py-4 space-y-1">
                            <?php if($team->phone): ?> <div class="text-xs"><i class="fab fa-whatsapp text-emerald-500 w-4"></i> <?php echo e($team->phone); ?></div> <?php endif; ?>
                            <?php if($team->email): ?> <div class="text-xs"><i class="far fa-envelope text-blue-500 w-4"></i> <?php echo e($team->email); ?></div> <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-center font-bold text-slate-400">
                            <?php echo e($team->urutan); ?>

                        </td>
                        <td class="px-6 py-4">
                            <div class="flex justify-center gap-2">
                                
                                <a href="<?php echo e(route('admin.teams.edit', $team->id)); ?>" class="w-8 h-8 rounded-lg bg-amber-100 text-amber-600 flex items-center justify-center hover:bg-amber-200 transition-colors" title="Edit">
                                    <i class="fas fa-edit text-xs"></i>
                                </a>

                                
                                <button onclick="confirmDelete(<?php echo e($team->id); ?>)" class="w-8 h-8 rounded-lg bg-red-100 text-red-600 flex items-center justify-center hover:bg-red-200 transition-colors" title="Hapus">
                                    <i class="fas fa-trash text-xs"></i>
                                </button>

                                
                                <form id="delete-form-<?php echo e($team->id); ?>" action="<?php echo e(route('admin.teams.destroy', $team->id)); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <script>
        function confirmDelete(id) {
            Swal.fire({
                title: 'Hapus Data Tim?',
                text: "Data yang dihapus tidak dapat dikembalikan!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444', // Merah
                cancelButtonColor: '#cbd5e1', // Abu-abu
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal',
                reverseButtons: true,
                customClass: {
                    popup: 'rounded-2xl', // Agar sudut membulat modern
                    confirmButton: 'font-bold px-4 py-2 rounded-lg',
                    cancelButton: 'font-bold px-4 py-2 rounded-lg'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    // Jika user klik Ya, submit form tersembunyi
                    document.getElementById('delete-form-' + id).submit();
                }
            })
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?><?php /**PATH C:\Users\JUMPER\Downloads\Company Syafa Fiks\Company Syafa Fiks\resources\views/admin/teams/index.blade.php ENDPATH**/ ?>