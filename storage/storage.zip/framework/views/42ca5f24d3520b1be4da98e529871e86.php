<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="mb-8">
        <h2 class="text-2xl font-black text-slate-800">Dashboard Manager Unit</h2>
        <p class="text-sm text-slate-500">Pusat kontrol dan unduhan laporan operasional.</p>
    </div>

    
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden mb-8">
        <div class="p-6 border-b border-slate-100 flex justify-between items-center bg-amber-50">
            <h3 class="font-bold text-amber-800 flex items-center gap-2">
                <i class="fas fa-user-tie"></i> Laporan Harian (LH) - Kepala Kantor
            </h3>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm text-slate-600">
                <thead class="bg-slate-50 border-b border-slate-200 text-xs uppercase font-bold">
                    <tr>
                        <th class="px-6 py-3">Tanggal</th>
                        <th class="px-6 py-3">Ringkasan Kegiatan</th>
                        <th class="px-6 py-3">Dokumentasi</th>
                        <th class="px-6 py-3 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $lhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-amber-50/30">
                        <td class="px-6 py-3 font-medium"><?php echo e(\Carbon\Carbon::parse($lh->tanggal)->format('d F Y')); ?></td>
                        <td class="px-6 py-3">
    <?php 
        // Cek apakah masih string JSON, jika iya decode, jika sudah array langsung gunakan
        $keg = is_string($lh->rincian_kegiatan) ? json_decode($lh->rincian_kegiatan, true) : $lh->rincian_kegiatan;
        
        // Pastikan $keg selalu array untuk menghindari error count()
        if (!is_array($keg)) $keg = [];
    ?>
    <ul class="list-disc list-inside text-xs">
        <li><?php echo e(Str::limit($keg[0] ?? '-', 50)); ?></li>
        <?php if(count($keg) > 1): ?> <li class="text-slate-400">+ <?php echo e(count($keg)-1); ?> lainnya</li> <?php endif; ?>
    </ul>
</td>
                        <td class="px-6 py-3">
                            <?php if($lh->dokumentasi): ?>
                                <a href="<?php echo e(asset('uploads/lh/'.$lh->dokumentasi)); ?>" target="_blank" class="text-blue-600 underline text-xs">Lihat Foto</a>
                            <?php else: ?>
                                <span class="text-slate-400 text-xs">-</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-3 text-center">
                            <a href="<?php echo e(route('manager_unit.lh.pdf', $lh->id)); ?>" class="inline-flex items-center gap-1 bg-red-100 text-red-600 px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-red-200 transition-colors">
                                <i class="fas fa-file-pdf"></i> Download PDF
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="text-center py-4 text-slate-400">Belum ada data LH.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div class="p-6 border-b border-slate-100 flex justify-between items-center bg-emerald-50">
            <h3 class="font-bold text-emerald-800 flex items-center gap-2">
                <i class="fas fa-users"></i> Laporan Kinerja Pegawai (LHKP)
            </h3>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm text-slate-600">
                <thead class="bg-slate-50 border-b border-slate-200 text-xs uppercase font-bold">
                    <tr>
                        <th class="px-6 py-3">Tanggal & Tempat</th>
                        <th class="px-6 py-3">Pegawai</th>
                        <th class="px-6 py-3">Progres Pekerjaan</th>
                        <th class="px-6 py-3 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $lhkps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lhkp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-emerald-50/30">
                        <td class="px-6 py-3">
                            <div class="font-bold"><?php echo e(\Carbon\Carbon::parse($lhkp->tanggal)->format('d/m/Y')); ?></div>
                            <div class="text-xs text-slate-500"><?php echo e($lhkp->tempat); ?></div>
                        </td>
                        <td class="px-6 py-3">
                            <div class="font-bold text-slate-700"><?php echo e($lhkp->nama_pegawai); ?></div>
                            <div class="text-xs text-slate-400"><?php echo e($lhkp->divisi); ?></div>
                        </td>
                        <td class="px-6 py-3 text-xs leading-relaxed max-w-xs truncate">
                            <?php echo e($lhkp->progres_pekerjaan); ?>

                        </td>
                        <td class="px-6 py-3 text-center">
                            <a href="<?php echo e(route('manager_unit.lhkp.pdf', $lhkp->id)); ?>" class="inline-flex items-center gap-1 bg-red-100 text-red-600 px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-red-200 transition-colors">
                                <i class="fas fa-file-pdf"></i> Download PDF
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="text-center py-4 text-slate-400">Belum ada data LHKP.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?><?php /**PATH C:\Users\JUMPER\Downloads\Company Syafa Fiks\Company Syafa Fiks\resources\views/manager-unit/dashboard.blade.php ENDPATH**/ ?>