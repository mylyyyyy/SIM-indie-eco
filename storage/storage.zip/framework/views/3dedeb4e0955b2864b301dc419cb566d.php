<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="scroll-smooth">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Syafa Group - Integrated Business Solution</title>

    <link rel="icon" href="<?php echo e(asset('img/favicon.png')); ?>" type="image/png">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/opendyslexic@latest/open-dyslexic.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <script src="https://cdn.tailwindcss.com"></script>

    
    <script src="//unpkg.com/alpinejs" defer></script>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        body {
            font-family: 'Inter', sans-serif;
            transition: filter 0.3s ease, font-size 0.3s ease;
        }

        /* Class untuk fitur aksesibilitas */
        .acc-grayscale { filter: grayscale(100%); }
        .acc-contrast { filter: invert(100%) hue-rotate(180deg); }
        .acc-dyslexia * { font-family: 'OpenDyslexic', sans-serif !important; }

        /* Custom Cursor Syafa Group (Biru) */
        .acc-cursor,
        .acc-cursor a,
        .acc-cursor button {
            cursor: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="%230EA5E9" stroke="%23FFF" stroke-width="2"><path d="M3 3l7.07 16.97 2.51-7.39 7.39-2.51L3 3z"/></svg>'), auto !important;
        }
    </style>
</head>

<body class="font-sans antialiased text-slate-900 bg-white leading-relaxed"
    x-data="accessibilityHandler()"
    :class="{ 
          'acc-grayscale': grayscale, 
          'acc-contrast': contrast, 
          'acc-dyslexia': dyslexia,
          'acc-cursor': bigCursor 
      }">

    
    <nav class="bg-gradient-to-r from-slate-900 via-blue-900 to-slate-900 backdrop-blur-md fixed w-full z-50 shadow-2xl border-b border-sky-800/30 transition-all duration-300">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-20">

                
                <div class="flex-shrink-0 flex items-center gap-4">
                    <a href="<?php echo e(url('/')); ?>" class="flex items-center gap-4 group">
                        <div class="relative">
                            
                            <div class="h-12 w-12 rounded-xl bg-gradient-to-br from-sky-400 to-blue-600 flex items-center justify-center text-white shadow-lg group-hover:scale-105 group-hover:rotate-6 transition-all duration-300 border border-white/20">
                                <i class="fa-solid fa-layer-group text-2xl"></i>
                            </div>
                            <div class="absolute -inset-1 bg-sky-500 rounded-xl blur opacity-20 group-hover:opacity-50 transition-opacity"></div>
                        </div>

                        <div class="flex flex-col">
                            <span class="font-bold text-white text-lg md:text-xl tracking-wide group-hover:text-sky-400 transition-colors duration-300">SYAFA GROUP</span>
                            <span class="text-[10px] text-sky-200 uppercase tracking-widest font-semibold hidden md:block">IT Solution & General Supplier</span>
                        </div>
                    </a>
                </div>

                
                <div class="hidden md:flex space-x-8 items-center">
                    <a href="<?php echo e(url('/')); ?>" class="text-gray-300 hover:text-white hover:border-b-2 hover:border-sky-400 px-1 py-2 text-sm font-semibold transition-all duration-300">Beranda</a>
                    <a href="<?php echo e(url('/#layanan')); ?>" class="text-gray-300 hover:text-white hover:border-b-2 hover:border-sky-400 px-1 py-2 text-sm font-semibold transition-all duration-300">Layanan</a>
                    <a href="<?php echo e(route('gallery.index')); ?>" class="text-gray-300 hover:text-white hover:border-b-2 hover:border-sky-400 px-1 py-2 text-sm font-semibold transition-all duration-300">Portofolio</a>
                    <a href="<?php echo e(route('news.public.index')); ?>" class="text-gray-300 hover:text-white hover:border-b-2 hover:border-sky-400 px-1 py-2 text-sm font-semibold transition-all duration-300">Berita</a>
                </div>

                
                <div class="hidden md:flex items-center gap-4">
                    
                    <a href="#kontak"
                        class="text-sm font-bold text-white bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 px-6 py-2.5 rounded-full transition-all duration-300 shadow-lg hover:shadow-sky-500/30 transform hover:-translate-y-1 whitespace-nowrap inline-flex items-center gap-2 group">
                        Hubungi Kami <i class="fa-solid fa-arrow-right text-xs group-hover:translate-x-1 transition-transform"></i>
                    </a>

                    <div class="h-6 w-px bg-slate-700/50 mx-1"></div>

                    
                    <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(url('/dashboard')); ?>" title="Dashboard"
                        class="p-2 text-slate-400 hover:text-sky-400 hover:bg-slate-800/50 rounded-full transition-all duration-300 hover:scale-110">
                        <i class="fa-solid fa-user-gear text-lg"></i>
                    </a>
                    <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" title="Login Staff"
                        class="group flex items-center gap-2 p-2 text-slate-400 hover:text-sky-400 hover:bg-slate-800/50 rounded-full transition-all duration-300 hover:scale-110">
                        <i class="fa-solid fa-lock text-lg"></i>
                    </a>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>

                
                <div class="-mr-2 flex md:hidden">
                    <button type="button" onclick="document.getElementById('mobile-menu').classList.toggle('hidden')" class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-slate-800/50 focus:outline-none transition-all duration-300 hover:scale-110">
                        <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                        </svg>
                    </button>
                </div>
            </div>
        </div>

        
        <div class="hidden md:hidden bg-slate-900 border-t border-slate-800" id="mobile-menu">
            <div class="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                <a href="<?php echo e(url('/')); ?>" class="block px-3 py-2 rounded-md text-base font-semibold text-white hover:bg-slate-800 transition-all">Beranda</a>
                <a href="#layanan" class="block px-3 py-2 rounded-md text-base font-semibold text-gray-300 hover:text-white hover:bg-slate-800 transition-all">Layanan</a>
                <a href="<?php echo e(route('gallery.index')); ?>" class="block px-3 py-2 rounded-md text-base font-semibold text-gray-300 hover:text-white hover:bg-slate-800 transition-all">Portofolio</a>
                <a href="#kontak" class="block w-full text-center px-5 py-3 mt-4 rounded-md text-base font-bold text-white bg-sky-600 hover:bg-sky-500 transition-all shadow-lg">
                    Hubungi Kami
                </a>
                <?php if(Route::has('login')): ?>
                <a href="<?php echo e(route('login')); ?>" class="block px-3 py-2 mt-2 rounded-md text-base font-medium text-gray-400 hover:text-sky-400 hover:bg-slate-800 transition-all">
                    <?php if(auth()->guard()->check()): ?> Dashboard <?php else: ?> Login Staff <?php endif; ?>
                </a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    
    <div class="pt-20">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    
    
    
    <div x-data="{ openAccess: false }" class="fixed bottom-6 left-6 z-50 print:hidden">

        
        <button @click="openAccess = !openAccess"
            class="flex items-center justify-center w-14 h-14 bg-slate-900 hover:bg-slate-800 text-sky-400 rounded-full shadow-2xl border-2 border-sky-500 transition transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-sky-400"
            aria-label="Menu Aksesibilitas">
            <i class="fa-solid fa-universal-access text-2xl"></i>
        </button>

        
        <div x-show="openAccess"
            style="display: none;"
            @click.away="openAccess = false"
            x-transition:enter="transition ease-out duration-300"
            x-transition:enter-start="opacity-0 translate-y-4 scale-90"
            x-transition:enter-end="opacity-100 translate-y-0 scale-100"
            x-transition:leave="transition ease-in duration-200"
            x-transition:leave-start="opacity-100 translate-y-0 scale-100"
            x-transition:leave-end="opacity-0 translate-y-4 scale-90"
            class="absolute bottom-16 left-0 w-72 bg-white rounded-xl shadow-2xl border border-gray-200 overflow-hidden">

            
            <div class="bg-slate-900 p-4 flex justify-between items-center text-white border-b border-slate-800">
                <h3 class="font-bold flex items-center gap-2 text-sky-400">
                    <i class="fa-solid fa-universal-access"></i> Aksesibilitas
                </h3>
                <button @click="openAccess = false" class="hover:text-sky-400 transition"><i class="fa-solid fa-times"></i></button>
            </div>

            
            <div class="p-4 space-y-5">

                
                <div class="bg-slate-50 p-3 rounded-lg border border-slate-200">
                    <p class="text-xs font-bold text-slate-500 uppercase mb-2">Pembaca Suara (TTS)</p>
                    <div class="flex gap-2">
                        <button @click="speak()" :disabled="isSpeaking" :class="isSpeaking ? 'opacity-50 cursor-not-allowed' : 'hover:bg-sky-400 hover:text-white'" class="flex-1 bg-slate-200 text-slate-700 py-2 rounded text-xs font-bold border border-slate-300 transition flex items-center justify-center gap-1">
                            <i class="fa-solid fa-play"></i> Baca
                        </button>
                        <button @click="stopSpeaking()" class="flex-1 bg-red-100 text-red-600 hover:bg-red-200 py-2 rounded text-xs font-bold border border-red-200 transition flex items-center justify-center gap-1">
                            <i class="fa-solid fa-stop"></i> Stop
                        </button>
                    </div>
                </div>

                
                <div>
                    <p class="text-xs font-bold text-slate-500 uppercase mb-2">Ukuran Teks</p>
                    <div class="flex gap-2">
                        <button @click="changeFontSize(-10)" class="flex-1 bg-slate-100 hover:bg-slate-200 py-2 rounded text-sm font-bold border border-slate-300 text-slate-700">A-</button>
                        <button @click="resetFontSize()" class="flex-1 bg-slate-100 hover:bg-slate-200 py-2 rounded text-sm font-bold border border-slate-300 text-slate-700">Normal</button>
                        <button @click="changeFontSize(10)" class="flex-1 bg-slate-100 hover:bg-slate-200 py-2 rounded text-sm font-bold border border-slate-300 text-slate-700">A+</button>
                    </div>
                </div>

                
                <div>
                    <p class="text-xs font-bold text-slate-500 uppercase mb-2">Tampilan Visual</p>
                    <div class="grid grid-cols-2 gap-2">
                        <button @click="grayscale = !grayscale" :class="grayscale ? 'bg-sky-500 text-white border-sky-600' : 'bg-slate-100 text-slate-600 border-slate-200'" class="py-2 px-3 rounded text-xs font-semibold border transition flex flex-col items-center gap-1">
                            <i class="fa-solid fa-eye-slash"></i> Grayscale
                        </button>
                        <button @click="contrast = !contrast" :class="contrast ? 'bg-sky-500 text-white border-sky-600' : 'bg-slate-100 text-slate-600 border-slate-200'" class="py-2 px-3 rounded text-xs font-semibold border transition flex flex-col items-center gap-1">
                            <i class="fa-solid fa-circle-half-stroke"></i> Kontras
                        </button>
                        <button @click="dyslexia = !dyslexia" :class="dyslexia ? 'bg-sky-500 text-white border-sky-600' : 'bg-slate-100 text-slate-600 border-slate-200'" class="py-2 px-3 rounded text-xs font-semibold border transition flex flex-col items-center gap-1">
                            <i class="fa-solid fa-font"></i> Disleksia
                        </button>
                        <button @click="bigCursor = !bigCursor" :class="bigCursor ? 'bg-sky-500 text-white border-sky-600' : 'bg-slate-100 text-slate-600 border-slate-200'" class="py-2 px-3 rounded text-xs font-semibold border transition flex flex-col items-center gap-1">
                            <i class="fa-solid fa-arrow-pointer"></i> Kursor
                        </button>
                    </div>
                </div>

                <button @click="resetAll()" class="w-full py-2 bg-red-50 text-red-600 text-xs font-bold rounded border border-red-200 hover:bg-red-100 transition">
                    <i class="fa-solid fa-rotate-left mr-1"></i> Reset Pengaturan
                </button>
            </div>
        </div>
    </div>

    
    
    
    <div x-data="{ openSurvey: false }" class="fixed bottom-6 right-6 z-40 print:hidden">

        <button @click="openSurvey = !openSurvey"
            class="flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-white px-5 py-3 rounded-full shadow-2xl border-2 border-sky-500 transition transform hover:scale-105 group">
            <span class="font-bold text-sm hidden group-hover:block transition-all duration-300">Feedback Layanan</span>
            <div class="relative">
                <i class="fa-regular fa-comments text-xl text-sky-400 animate-pulse"></i>
            </div>
        </button>

        
        <div x-show="openSurvey"
            x-transition:enter="transition ease-out duration-300"
            x-transition:enter-start="opacity-0 translate-y-4 scale-90"
            x-transition:enter-end="opacity-100 translate-y-0 scale-100"
            x-transition:leave="transition ease-in duration-200"
            x-transition:leave-start="opacity-100 translate-y-0 scale-100"
            x-transition:leave-end="opacity-0 translate-y-4 scale-90"
            class="absolute bottom-16 right-0 w-80 md:w-96 bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden"
            style="display: none;">

            <div class="bg-gradient-to-r from-slate-900 to-blue-900 p-4 flex justify-between items-center">
                <div>
                    <h3 class="text-white font-bold text-lg">Kepuasan Klien</h3>
                    <p class="text-xs text-sky-400">Pendapat Anda berharga bagi kami</p>
                </div>
                <button @click="openSurvey = false" class="text-gray-400 hover:text-white transition">
                    <i class="fa-solid fa-times"></i>
                </button>
            </div>

            <div class="p-5">
                <form action="<?php echo e(route('survey.store')); ?>" method="POST" id="surveyForm" onsubmit="return handleSurvey(event)">
                    <?php echo csrf_field(); ?>
                    <div class="mb-4 text-center">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Bagaimana layanan kami?</label>
                        <div class="flex justify-center gap-3">
                            <label class="cursor-pointer group">
                                <input type="radio" name="rating" value="1" class="hidden peer" required>
                                <div class="text-3xl grayscale peer-checked:grayscale-0 group-hover:scale-125 transition">😞</div>
                            </label>
                            <label class="cursor-pointer group">
                                <input type="radio" name="rating" value="2" class="hidden peer">
                                <div class="text-3xl grayscale peer-checked:grayscale-0 group-hover:scale-125 transition">😐</div>
                            </label>
                            <label class="cursor-pointer group">
                                <input type="radio" name="rating" value="3" class="hidden peer">
                                <div class="text-3xl grayscale peer-checked:grayscale-0 group-hover:scale-125 transition">😊</div>
                            </label>
                            <label class="cursor-pointer group">
                                <input type="radio" name="rating" value="4" class="hidden peer">
                                <div class="text-3xl grayscale peer-checked:grayscale-0 group-hover:scale-125 transition">🤩</div>
                            </label>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 mb-1">Pesan / Masukan</label>
                        <textarea name="saran" rows="3" class="w-full text-sm rounded-lg border-gray-300 focus:border-sky-500 focus:ring-sky-500 shadow-sm" placeholder="Tulis masukan Anda..."></textarea>
                    </div>

                    <button type="submit" id="submitSurvey" class="w-full bg-sky-500 hover:bg-sky-600 text-white font-bold py-2 rounded-lg transition shadow-md disabled:opacity-50">
                        <span id="submitText">Kirim Penilaian</span>
                        <span id="loadingText" class="hidden">Mengirim...</span>
                    </button>
                </form>
            </div>
        </div>
    </div>

    
    <footer class="bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 text-white pt-16 pb-8 border-t border-slate-800/50 relative overflow-hidden">
        
        <div class="absolute inset-0 z-0">
            <div class="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%23ffffff\' fill-opacity=\'0.03\'%3E%3Cpath d=\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-20"></div>
        </div>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-16 items-start">

                
                <div class="w-full h-64 md:h-80 rounded-2xl overflow-hidden shadow-2xl border border-slate-700/50 relative group">
                    <iframe
                        src="https://maps.google.com/maps?q=Jombang&t=&z=13&ie=UTF8&iwloc=&output=embed"
                        class="w-full h-full border-0 filter grayscale group-hover:grayscale-0 transition duration-500"
                        allowfullscreen="" loading="lazy">
                    </iframe>
                    <div class="absolute bottom-4 left-4 bg-white/90 backdrop-blur text-slate-900 px-4 py-2 rounded-lg text-xs font-bold shadow-lg">
                        📍 Kantor Pusat Syafa Group
                    </div>
                </div>

                
                <div class="flex flex-col justify-center space-y-8">
                    <div>
                        <div class="flex items-center gap-3 mb-4">
                            <div class="h-10 w-10 bg-sky-500 rounded-lg flex items-center justify-center text-white">
                                <i class="fa-solid fa-layer-group text-xl"></i>
                            </div>
                            <div>
                                <h3 class="text-xl font-bold text-white tracking-wide">SYAFA GROUP</h3>
                                <p class="text-xs text-sky-400 font-semibold tracking-wider uppercase">Integrated Business Solution</p>
                            </div>
                        </div>
                        <p class="text-slate-400 text-sm leading-relaxed max-w-md">
                            Mitra strategis Anda dalam penyediaan solusi IT, pengadaan barang, dan konsultasi bisnis yang terpercaya dan profesional.
                        </p>
                    </div>

                    <div class="space-y-4">
                        <div class="flex items-start gap-4 group">
                            <div class="bg-slate-800/50 p-3 rounded-lg text-sky-500 group-hover:bg-sky-500 group-hover:text-white transition-all duration-300 border border-slate-700/30">
                                <i class="fa-solid fa-location-dot text-lg"></i>
                            </div>
                            <div>
                                <p class="text-xs text-slate-400 font-bold uppercase mb-1">Alamat Kantor</p>
                                <p class="text-white font-medium leading-snug">
                                    Jl. KH. Wahid Hasyim No.155<br>
                                    Jombang, Jawa Timur 61419
                                </p>
                            </div>
                        </div>

                        <div class="flex items-start gap-4 group">
                            <div class="bg-slate-800/50 p-3 rounded-lg text-blue-500 group-hover:bg-blue-500 group-hover:text-white transition-all duration-300 border border-slate-700/30">
                                <i class="fa-solid fa-phone text-lg"></i>
                            </div>
                            <div>
                                <p class="text-xs text-slate-400 font-bold uppercase mb-1">Hubungi Kami</p>
                                <p class="text-white font-medium hover:text-sky-400 transition-colors cursor-pointer">
                                    (0321) 123456
                                </p>
                            </div>
                        </div>
                    </div>

                    
                    <div class="flex gap-4">
                        <a href="#" class="w-10 h-10 flex items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:bg-blue-600 hover:text-white transition-all">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="w-10 h-10 flex items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:bg-pink-600 hover:text-white transition-all">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="#" class="w-10 h-10 flex items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:bg-blue-400 hover:text-white transition-all">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                    </div>
                </div>
            </div>

            <div class="mt-12 pt-8 border-t border-slate-800/50 text-center text-slate-500 text-sm">
                <p>© <?php echo e(date('Y')); ?> Syafa Group. All rights reserved.</p>
            </div>
        </div>
    </footer>

    
    <script>
        // 1. Logic Survey AJAX
        function handleSurvey(e) {
            e.preventDefault();
            const form = document.getElementById('surveyForm');
            const submitBtn = document.getElementById('submitSurvey');
            const submitText = document.getElementById('submitText');
            const loadingText = document.getElementById('loadingText');

            submitBtn.disabled = true;
            submitText.classList.add('hidden');
            loadingText.classList.remove('hidden');

            // Simulasi Request (Ganti dengan fetch asli jika route sudah siap)
            setTimeout(() => {
                Swal.fire({
                    icon: 'success',
                    title: 'Terima Kasih!',
                    text: 'Masukan Anda telah kami terima.',
                    timer: 3000,
                    showConfirmButton: false,
                    toast: true,
                    position: 'top-end'
                });
                form.reset();
                submitBtn.disabled = false;
                submitText.classList.remove('hidden');
                loadingText.classList.add('hidden');
                
                // Tutup modal
                document.querySelector('[x-data="{ openSurvey: false }"] button i.fa-times').parentElement.click();
            }, 1000);

            // Jika route backend sudah siap, uncomment kode fetch di bawah ini:
            /*
            const formData = new FormData(form);
            fetch(form.action, {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                }
            })
            .then(res => res.json())
            .then(data => { ... })
            */

            return false;
        }

        // 2. Logic Aksesibilitas
        function accessibilityHandler() {
            return {
                grayscale: false,
                contrast: false,
                dyslexia: false,
                bigCursor: false,
                fontSize: 100,
                isSpeaking: false,
                synth: window.speechSynthesis,
                utterance: null,

                changeFontSize(amount) {
                    this.fontSize += amount;
                    if (this.fontSize < 80) this.fontSize = 80;
                    if (this.fontSize > 130) this.fontSize = 130;
                    document.documentElement.style.fontSize = this.fontSize + '%';
                },

                resetFontSize() {
                    this.fontSize = 100;
                    document.documentElement.style.fontSize = '100%';
                },

                resetAll() {
                    this.grayscale = false;
                    this.contrast = false;
                    this.dyslexia = false;
                    this.bigCursor = false;
                    this.resetFontSize();
                    this.stopSpeaking();
                },

                speak() {
                    this.stopSpeaking();
                    let text = window.getSelection().toString();
                    if (!text) text = document.body.innerText;

                    if (text) {
                        this.utterance = new SpeechSynthesisUtterance(text);
                        this.utterance.lang = 'id-ID';
                        this.utterance.onend = () => { this.isSpeaking = false; };
                        this.synth.speak(this.utterance);
                        this.isSpeaking = true;
                    }
                },

                stopSpeaking() {
                    if (this.synth.speaking) {
                        this.synth.cancel();
                        this.isSpeaking = false;
                    }
                }
            }
        }

        document.addEventListener('alpine:init', () => {
            Alpine.data('inView', () => ({
                inView: false,
                init() {
                    const observer = new IntersectionObserver((entries) => {
                        entries.forEach(entry => {
                            if (entry.isIntersecting) {
                                this.inView = true;
                                observer.unobserve(this.$el);
                            }
                        });
                    }, { threshold: 0.1 });
                    observer.observe(this.$el);
                }
            }));
        });
    </script>

</body>
</html><?php /**PATH C:\Users\Chaps\Company tunjung namanya\resources\views/layouts/main.blade.php ENDPATH**/ ?>