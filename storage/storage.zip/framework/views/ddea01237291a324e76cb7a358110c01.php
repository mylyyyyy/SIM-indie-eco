<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Admin Panel - Contractor System</title>
    <link rel="icon" href="<?php echo e(asset('img/logo.png')); ?>" type="image/png">

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="//unpkg.com/alpinejs" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        [x-cloak] { display: none !important; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        
        /* Custom Scrollbar */
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: #f1f5f9; }
        ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
    </style>
</head>
<body class="font-sans antialiased bg-slate-50 text-slate-600">

    <div class="min-h-screen flex bg-slate-50" x-data="{ sidebarOpen: false }">
        
        
        <aside class="fixed inset-y-0 left-0 z-50 w-72 bg-slate-900 text-white transition-transform duration-300 transform shadow-2xl"
            :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'">
            
            
            <div class="flex items-center gap-3 h-20 px-6 border-b border-slate-800 bg-slate-950">
                <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo" class="h-10 w-auto">
                <div class="flex flex-col">
                    <span class="text-lg font-black tracking-tight text-white leading-tight">SYAFA GROUP</span>
                    <span class="text-[10px] font-bold text-blue-500 tracking-widest uppercase">Internal System</span>
                </div>
            </div>

            
            <nav class="flex-1 px-4 py-6 space-y-1 overflow-y-auto h-[calc(100vh-5rem)]">
                
                
                <?php if(Auth::user()->role == 'admin'): ?>
                    <div class="mb-2 px-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Utama</div>
                    
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="flex items-center px-4 py-3.5 rounded-xl transition-all duration-200 group <?php echo e(request()->routeIs('admin.dashboard') ? 'bg-blue-600 text-white shadow-[0_0_20px_rgba(37,99,235,0.3)]' : 'text-slate-400 hover:bg-slate-800 hover:text-white'); ?>">
                        <i class="fas fa-home w-5 text-center <?php echo e(request()->routeIs('admin.dashboard') ? 'text-white' : 'text-slate-500 group-hover:text-white'); ?>"></i>
                        <span class="ml-3 font-medium">Dashboard</span>
                    </a>

                    <div class="mt-6 mb-2 px-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Master Data</div>
                    
                    <a href="<?php echo e(route('admin.users.index')); ?>" class="flex items-center px-4 py-3.5 rounded-xl transition-all duration-200 group <?php echo e(request()->routeIs('admin.users.*') ? 'bg-blue-600 text-white shadow-[0_0_20px_rgba(37,99,235,0.3)]' : 'text-slate-400 hover:bg-slate-800 hover:text-white'); ?>">
                        <i class="fas fa-users w-5 text-center <?php echo e(request()->routeIs('admin.users.*') ? 'text-white' : 'text-slate-500 group-hover:text-white'); ?>"></i>
                        <span class="ml-3 font-medium">Data Pengguna</span>
                    </a>

                    <a href="<?php echo e(route('admin.projects.index')); ?>" class="flex items-center px-4 py-3.5 rounded-xl transition-all duration-200 group <?php echo e(request()->routeIs('admin.projects.*') ? 'bg-blue-600 text-white shadow-[0_0_20px_rgba(37,99,235,0.3)]' : 'text-slate-400 hover:bg-slate-800 hover:text-white'); ?>">
                        <i class="fas fa-building w-5 text-center <?php echo e(request()->routeIs('admin.projects.*') ? 'text-white' : 'text-slate-500 group-hover:text-white'); ?>"></i>
                        <span class="ml-3 font-medium">Data Proyek</span>
                    </a>
                <?php endif; ?>

                
                <?php if(Auth::user()->role == 'subkon_pt'): ?>
                    <div class="mb-2 px-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Monitoring</div>
                    <a href="<?php echo e(route('subkon-pt.dashboard')); ?>" class="flex items-center px-4 py-3.5 rounded-xl transition-all duration-200 group <?php echo e(request()->routeIs('subkon-pt.dashboard') ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-800 hover:text-white'); ?>">
                        <i class="fas fa-chart-pie w-5 text-center"></i>
                        <span class="ml-3 font-medium">Dashboard Monitoring</span>
                    </a>
                <?php endif; ?>

           

                <?php if(Auth::user()->role == 'subkon_eks'): ?>
                    <div class="mb-2 px-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Pekerjaan</div>
                    <a href="<?php echo e(route('subkon-eks.dashboard')); ?>" class="flex items-center px-4 py-3.5 rounded-xl transition-all duration-200 group <?php echo e(request()->routeIs('subkon-eks.dashboard') ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-800 hover:text-white'); ?>">
                        <i class="fas fa-briefcase w-5 text-center"></i>
                        <span class="ml-3 font-medium">Proyek Saya</span>
                    </a>
                    
                    
                    <a href="<?php echo e(route('subkon-eks.reports.create')); ?>" class="flex items-center px-4 py-3.5 rounded-xl transition-all duration-200 group <?php echo e(request()->routeIs('subkon-eks.reports.create') ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-800 hover:text-white'); ?>">
                        <i class="fas fa-file-upload w-5 text-center"></i>
                        <span class="ml-3 font-medium">Input Laporan</span>
                    </a>
                <?php endif; ?>
            </nav>

            
            <div class="border-t border-slate-800 p-4 bg-slate-950">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-sm">
                        <?php echo e(substr(Auth::user()->name, 0, 1)); ?>

                    </div>
                    <div class="flex-1 min-w-0">
                        <p class="text-sm font-bold text-white truncate"><?php echo e(Auth::user()->name); ?></p>
                        <p class="text-xs text-slate-400 truncate capitalize"><?php echo e(str_replace('_', ' ', Auth::user()->role)); ?></p>
                    </div>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="text-slate-400 hover:text-red-400 transition-colors" title="Keluar">
                            <i class="fas fa-power-off"></i>
                        </button>
                    </form>
                </div>
            </div>
        </aside>

        
        <div class="flex-1 flex flex-col md:ml-72 transition-all duration-300">
            
            
            <header class="h-20 bg-white/80 backdrop-blur-md border-b border-slate-200 flex items-center justify-between px-6 sticky top-0 z-40">
                
                
                <div class="flex items-center gap-4">
                    <button @click="sidebarOpen = !sidebarOpen" class="text-slate-500 hover:text-slate-800 focus:outline-none md:hidden">
                        <i class="fas fa-bars text-2xl"></i>
                    </button>
                    
                    <h2 class="text-xl font-bold text-slate-800 hidden md:block">
                        <?php if(request()->routeIs('admin.dashboard')): ?> Overview Dashboard
                        <?php elseif(request()->routeIs('admin.users.*')): ?> Manajemen Pengguna
                        <?php elseif(request()->routeIs('admin.projects.*')): ?> Manajemen Proyek
                        <?php else: ?> Halaman Sistem
                        <?php endif; ?>
                    </h2>
                </div>

                
                <div class="flex items-center gap-4">
                    
                    <button class="w-10 h-10 rounded-full bg-slate-50 text-slate-500 hover:bg-blue-50 hover:text-blue-600 flex items-center justify-center transition-all relative">
                        <i class="fas fa-bell"></i>
                        <span class="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full"></span>
                    </button>

                    
                    <div x-data="{ open: false }" class="relative">
                        <button @click="open = !open" class="flex items-center gap-2 focus:outline-none">
                            <span class="text-sm font-semibold text-slate-600 hidden md:block text-right">
                                Halo, <?php echo e(Auth::user()->name); ?>

                            </span>
                            <div class="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-bold shadow-lg shadow-blue-500/20">
                                <?php echo e(substr(Auth::user()->name, 0, 1)); ?>

                            </div>
                        </button>

                        
                        <div x-show="open" @click.away="open = false" 
                             class="absolute right-0 mt-3 w-48 bg-white rounded-xl shadow-xl border border-slate-100 py-2 animate__animated animate__fadeIn animate__faster"
                             style="display: none;">
                            <a href="<?php echo e(route('profile.edit')); ?>" class="block px-4 py-2 text-sm text-slate-600 hover:bg-slate-50 hover:text-blue-600">
                                <i class="fas fa-user-circle w-5"></i> Profil Saya
                            </a>
                            <div class="border-t border-slate-100 my-1"></div>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 font-medium">
                                    <i class="fas fa-sign-out-alt w-5"></i> Keluar
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </header>

            
            <main class="p-6 md:p-8 flex-1 overflow-y-auto">
                <?php echo e($slot); ?>

            </main>
        </div>

        
        <div x-show="sidebarOpen" @click="sidebarOpen = false" 
             class="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-sm md:hidden transition-opacity" 
             style="display: none;"></div>
    </div>
</body>
</html><?php /**PATH C:\Users\JUMPER\Downloads\Company tunjung namanya\Company tunjung namanya\resources\views/components/admin-layout.blade.php ENDPATH**/ ?>