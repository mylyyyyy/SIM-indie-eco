<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <div class="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
            <h2 class="text-2xl font-black text-slate-800">Hasil Kunjungan Toko</h2>
            <p class="text-sm text-slate-500">Input data setoran dan rincian kunjungan operasional.</p>
        </div>
        
        
        <div>
            <a href="<?php echo e(route('eco.visit-results.export')); ?>" target="_blank" 
               class="inline-flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-lg shadow-teal-500/30 transition-all transform hover:-translate-y-0.5">
                <i class="fas fa-file-excel"></i> Download Laporan Excel
            </a>
        </div>
    </div>

    <?php if(session('success')): ?>
        <script>Swal.fire({ icon: 'success', title: 'Berhasil', text: "<?php echo e(session('success')); ?>", timer: 2500, showConfirmButton: false });</script>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        
        <div class="lg:col-span-1 bg-white rounded-2xl shadow-sm border border-slate-200 p-6 h-fit sticky top-24">
            <h3 class="font-bold text-slate-800 mb-4 border-b border-slate-100 pb-2">Input Hasil Kunjungan</h3>
            
            <form action="<?php echo e(route('eco.visit-results.store')); ?>" method="POST" class="space-y-3">
                <?php echo csrf_field(); ?>
                
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Hari</label>
                        <select name="hari" class="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white" required>
                            <option value="Senin">Senin</option><option value="Selasa">Selasa</option>
                            <option value="Rabu">Rabu</option><option value="Kamis">Kamis</option>
                            <option value="Jumat">Jumat</option><option value="Sabtu">Sabtu</option><option value="Minggu">Minggu</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Tanggal</label>
                        <input type="date" name="tanggal" value="<?php echo e(date('Y-m-d')); ?>" class="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm" required>
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Nama Toko</label>
                    <input type="text" name="nama_toko" class="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:ring-emerald-500 focus:border-emerald-500" placeholder="Ketik nama toko..." required>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Alamat</label>
                    <textarea name="alamat" rows="2" class="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:ring-emerald-500 focus:border-emerald-500" placeholder="Alamat toko..." required></textarea>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Sisa Awal (Pack)</label>
                        <input type="number" min="0" name="titip_sisa_awal_pack" class="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm" value="0" required>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Harga (Rp)</label>
                        <input type="number" min="0" name="harga_rp" class="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm" value="0" required>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Laku (Pack)</label>
                        <input type="number" min="0" name="laku_pack" class="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm" value="0" required>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Sisa (Pack)</label>
                        <input type="number" min="0" name="sisa_pack" id="sisa_pack" class="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm" value="0" oninput="calculateTotal()" required>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Tambah (Pack)</label>
                        <input type="number" min="0" name="tambah_pack" id="tambah_pack" class="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm" value="0" oninput="calculateTotal()" required>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Total (Pack)</label>
                        <input type="number" min="0" name="total_pack" id="total_pack" class="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-slate-100" value="0" readonly required>
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Ket / Pembayaran</label>
                    <input type="text" name="keterangan_bayar" class="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm" placeholder="Contoh: Lunas / Cash / Transfer">
                </div>

                <button type="submit" class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 rounded-lg shadow mt-2 transform hover:-translate-y-0.5 transition-all">Simpan Data</button>
            </form>
            
            <script>
                function calculateTotal() {
                    let sisa = parseInt(document.getElementById('sisa_pack').value) || 0;
                    let tambah = parseInt(document.getElementById('tambah_pack').value) || 0;
                    document.getElementById('total_pack').value = sisa + tambah;
                }
            </script>
        </div>

        
        <div class="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left text-sm text-slate-600">
                    <thead class="bg-slate-50 border-b border-slate-200 text-xs uppercase text-slate-500 font-bold">
                        <tr>
                            <th class="px-4 py-3">Tanggal</th>
                            <th class="px-4 py-3">Toko & Alamat</th>
                            <th class="px-4 py-3 text-center">Harga</th>
                            <th class="px-4 py-3 text-center">Laku</th>
                            <th class="px-4 py-3 text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50 transition-colors">
                            <td class="px-4 py-3">
                                <div class="font-bold text-slate-800"><?php echo e(\Carbon\Carbon::parse($item->tanggal)->format('d/m/Y')); ?></div>
                                <div class="text-[10px] text-slate-500 uppercase"><?php echo e($item->hari); ?></div>
                            </td>
                            <td class="px-4 py-3">
                                <div class="font-bold text-slate-700"><?php echo e($item->nama_toko); ?></div>
                                <div class="text-[10px] text-slate-400 truncate max-w-[150px]" title="<?php echo e($item->alamat); ?>"><?php echo e($item->alamat); ?></div>
                            </td>
                            <td class="px-4 py-3 text-center font-medium">Rp <?php echo e(number_format($item->harga_rp, 0, ',', '.')); ?></td>
                            <td class="px-4 py-3 text-center font-bold text-emerald-600"><?php echo e($item->laku_pack); ?> Pack</td>
                            <td class="px-4 py-3 text-center">
                                <form action="<?php echo e(route('eco.visit-results.destroy', $item->id)); ?>" method="POST" onsubmit="return confirm('Hapus data ini?');">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-500 hover:bg-red-50 p-1.5 rounded transition-colors"><i class="fas fa-trash text-xs"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="text-center py-8 text-slate-400">Belum ada data.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?><?php /**PATH C:\Users\JUMPER\Downloads\Company Syafa Fiks\Company Syafa Fiks\resources\views/eco/operasional/visit-result/index.blade.php ENDPATH**/ ?>