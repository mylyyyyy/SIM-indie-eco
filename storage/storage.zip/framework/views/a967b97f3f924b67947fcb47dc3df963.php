<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="scroll-smooth">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Portofolio - Syafa Group</title>
    <link rel="icon" href="<?php echo e(asset('img/favicon.png')); ?>" type="image/png">

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="//unpkg.com/alpinejs" defer></script>

    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        ::-webkit-scrollbar { width: 10px; }
        ::-webkit-scrollbar-track { background: #eff6ff; }
        ::-webkit-scrollbar-thumb { background: #1e40af; border-radius: 5px; } 
    </style>
</head>

<body class="antialiased text-slate-600 bg-slate-50">

    
    <nav class="fixed w-full z-50 bg-blue-900 shadow-xl border-b border-blue-800">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-20">
                <a href="<?php echo e(url('/')); ?>" class="flex items-center gap-3 group">
                    <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo" class="h-10 w-auto bg-white p-1 rounded-lg shadow-md transition-transform group-hover:scale-110">
                    <div class="flex flex-col">
                        <span class="font-black text-xl tracking-tight leading-none text-white">SYAFA <span class="text-blue-300">GROUP</span></span>
                        <span class="text-[10px] font-bold tracking-widest uppercase mt-0.5 text-blue-200/80">Integrated Solution</span>
                    </div>
                </a>
                <div class="flex items-center gap-4">
                    <a href="<?php echo e(url('/')); ?>" class="text-blue-200 hover:text-white font-bold text-sm transition-colors"><i class="fas fa-arrow-left mr-2"></i> Kembali</a>
                </div>
            </div>
        </div>
    </nav>

    
    <section class="pt-32 pb-12 bg-blue-900 relative overflow-hidden">
        <div class="absolute top-0 right-0 w-96 h-96 bg-blue-600 rounded-full blur-[150px] opacity-30"></div>
        <div class="container mx-auto px-6 text-center relative z-10">
            <h1 class="text-4xl md:text-5xl font-black text-white mb-4" data-aos="fade-down">Portofolio Proyek</h1>
            <p class="text-blue-200 text-lg max-w-2xl mx-auto" data-aos="fade-up" data-aos-delay="100">
                Rekam jejak dedikasi kami dalam membangun infrastruktur dan hunian berkualitas di berbagai wilayah.
            </p>
        </div>
    </section>

    
    <section class="py-20 bg-slate-50">
        <div class="container mx-auto px-6">
            
            
            <?php
                $projects = [
                    [
                        'img' => '1.jpeg',
                        'title' => 'Cluster Grand Syafa Residence',
                        'loc' => 'Kota Surabaya, Jawa Timur',
                        'type' => 'Hunian Eksklusif',
                        'specs' => [
                            'Luas Tanah' => '120 m²',
                            'Luas Bangunan' => '90 m²',
                            'Kamar' => '3 KT / 2 KM',
                            'Lantai' => '2 Lantai'
                        ],
                        'desc' => 'Hunian modern dengan konsep eco-living di jantung kota Surabaya. Dilengkapi dengan smart home system dan akses mudah ke pusat perbelanjaan.'
                    ],
                    [
                        'img' => '2.jpeg',
                        'title' => 'Syafa Commercial Park',
                        'loc' => 'Kab. Malang, Jawa Timur',
                        'type' => 'Ruko & Pergudangan',
                        'specs' => [
                            'Luas Area' => '5 Hektar',
                            'Unit' => '40 Unit Ruko',
                            'Fasilitas' => 'Parkir Luas',
                            'Keamanan' => '24 Jam CCTV'
                        ],
                        'desc' => 'Kawasan komersial terpadu yang dirancang untuk menunjang distribusi logistik PT. Eco Syafa Harvest. Lokasi strategis di jalur provinsi.'
                    ],
                    [
                        'img' => '3.jpeg',
                        'title' => 'Athena Bridge Construction',
                        'loc' => 'Jawa Tengah',
                        'type' => 'Infrastruktur Publik',
                        'specs' => [
                            'Panjang' => '150 Meter',
                            'Lebar' => '12 Meter',
                            'Material' => 'Beton Pratekan',
                            'Durasi' => '12 Bulan'
                        ],
                        'desc' => 'Proyek strategis pembangunan jembatan penghubung antar kabupaten yang dikerjakan oleh PT. Athena Syafa Panca dengan standar keamanan tinggi.'
                    ],
                    [
                        'img' => '4.jpeg',
                        'title' => 'Gedung Serbaguna Syafa',
                        'loc' => 'Probolinggo, Jawa Timur',
                        'type' => 'Fasilitas Umum',
                        'specs' => [
                            'Kapasitas' => '1000 Orang',
                            'Luas Hall' => '800 m²',
                            'Parkir' => '100 Mobil',
                            'Fitur' => 'Sound System Premium'
                        ],
                        'desc' => 'Gedung pertemuan multifungsi yang dapat digunakan untuk pernikahan, seminar, dan acara korporat dengan arsitektur kontemporer.'
                    ],
                    [
                        'img' => '5.jpeg',
                        'title' => 'Perumahan Subsidi Asri',
                        'loc' => 'Jember, Jawa Timur',
                        'type' => 'Rumah Subsidi',
                        'specs' => [
                            'Tipe' => '36/60',
                            'Total Unit' => '200 Unit',
                            'Konstruksi' => 'Bata Ringan',
                            'Air' => 'PDAM'
                        ],
                        'desc' => 'Komitmen kami dalam menyediakan hunian terjangkau namun berkualitas bagi masyarakat berpenghasilan rendah (MBR).'
                    ],
                    [
                        'img' => '1.jpeg', // Loop balik ke 1 karena request gambar cuma 1-5
                        'title' => 'Renovasi Kantor Pemerintahan',
                        'loc' => 'Semarang, Jawa Tengah',
                        'type' => 'Renovasi Gedung',
                        'specs' => [
                            'Luas' => '500 m²',
                            'Lingkup' => 'Interior & Eksterior',
                            'Style' => 'Modern Minimalis',
                            'Tahun' => '2025'
                        ],
                        'desc' => 'Proyek revitalisasi gedung layanan publik untuk meningkatkan kenyamanan dan efisiensi pelayanan masyarakat.'
                    ]
                ];
            ?>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="group bg-white rounded-3xl overflow-hidden border border-slate-100 shadow-lg hover:shadow-2xl hover:-translate-y-2 transition-all duration-500" data-aos="fade-up" data-aos-delay="<?php echo e($index * 100); ?>">
                    
                    
                    <div class="relative h-64 overflow-hidden">
                        
                        <div class="absolute inset-0 bg-gradient-to-t from-blue-900/80 via-transparent to-transparent opacity-60 z-10"></div>
                        
                        
                        <div class="absolute top-4 right-4 z-20">
                            <span class="bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-full shadow-md uppercase tracking-wider">
                                <?php echo e($project['type']); ?>

                            </span>
                        </div>

                        
                        <img src="<?php echo e(asset('img/porto/' . $project['img'])); ?>" 
                             alt="<?php echo e($project['title']); ?>" 
                             class="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                             onerror="this.onerror=null; this.src='https://via.placeholder.com/600x400/1e3a8a/ffffff?text=Syafa+Project';">
                        
                        
                        <div class="absolute bottom-4 left-4 z-20 flex items-center text-white text-sm font-medium">
                            <i class="fa-solid fa-location-dot text-cyan-400 mr-2"></i>
                            <?php echo e($project['loc']); ?>

                        </div>
                    </div>

                    
                    <div class="p-6">
                        <h3 class="text-xl font-black text-slate-800 mb-3 group-hover:text-blue-600 transition-colors"><?php echo e($project['title']); ?></h3>
                        
                        
                        <p class="text-slate-500 text-sm leading-relaxed mb-6 line-clamp-3">
                            <?php echo e($project['desc']); ?>

                        </p>

                        
                        <div class="bg-blue-50/50 rounded-2xl p-4 border border-blue-100">
                            <h4 class="text-xs font-bold text-blue-800 uppercase mb-3 flex items-center gap-2">
                                <i class="fa-solid fa-list-check"></i> Spesifikasi Teknis
                            </h4>
                            <div class="grid grid-cols-2 gap-y-2 gap-x-4 text-xs">
                                <?php $__currentLoopData = $project['specs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div>
                                        <span class="block text-slate-400 font-medium"><?php echo e($key); ?></span>
                                        <span class="block text-slate-700 font-bold"><?php echo e($value); ?></span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </section>

    
    <footer class="bg-blue-950 text-white py-8 border-t-4 border-blue-600 text-center">
        <p class="text-sm text-blue-200">© <?php echo e(date('Y')); ?> Syafa Group. All Rights Reserved.</p>
    </footer>

    
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init({ once: true, duration: 800 });
    </script>
</body>
</html><?php /**PATH C:\Users\JUMPER\Downloads\Company tunjung namanya\Company tunjung namanya\resources\views/portfolio.blade.php ENDPATH**/ ?>