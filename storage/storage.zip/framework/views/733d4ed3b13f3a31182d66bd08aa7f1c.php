<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div>
            <h2 class="text-2xl font-black text-slate-800">Stok Beras di Toko</h2>
            <p class="text-sm text-slate-500">Pencatatan jumlah stok beras 2.5kg dan 5kg di setiap toko mitra.</p>
        </div>
        <div>
            <a href="<?php echo e(route('eco.store-rice-stocks.export')); ?>" target="_blank" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-xl font-bold text-sm shadow-md transition-all flex items-center gap-2">
                <i class="fas fa-file-pdf"></i> Unduh PDF Laporan
            </a>
        </div>
    </div>

    <?php if(session('success')): ?>
        <script>
            Swal.fire({ icon: 'success', title: 'Berhasil', text: "<?php echo e(session('success')); ?>", timer: 2500, showConfirmButton: false });
        </script>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        
        <div class="lg:col-span-1">
            <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
                <h3 class="font-bold text-slate-800 mb-4 border-b border-slate-100 pb-2">Input Stok Toko</h3>
                
                <form action="<?php echo e(route('eco.store-rice-stocks.store')); ?>" method="POST" class="space-y-4">
                    <?php echo csrf_field(); ?>
                    
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Tanggal</label>
                        <input type="date" name="tanggal" value="<?php echo e(date('Y-m-d')); ?>" class="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:ring-emerald-500" required>
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Nama Admin</label>
                        
                        <input type="text" name="nama_admin" value="<?php echo e(Auth::user()->name); ?>" class="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:ring-emerald-500 bg-slate-50" readonly required>
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Nama Toko Mitra</label>
                        <select name="nama_toko" class="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:ring-emerald-500 bg-white" required>
                            <option value="" disabled selected>-- Pilih Toko Mitra --</option>
                            <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($store->nama_toko); ?>"><?php echo e($store->nama_toko); ?> (<?php echo e($store->kantor_cabang); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Stok 2.5 Kg</label>
                            <div class="relative">
                                <input type="number" min="0" name="stok_2_5kg" class="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:ring-emerald-500" placeholder="0" required>
                                <span class="absolute right-3 top-2 text-slate-400 text-xs font-bold">Pack</span>
                            </div>
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Stok 5 Kg</label>
                            <div class="relative">
                                <input type="number" min="0" name="stok_5kg" class="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:ring-emerald-500" placeholder="0" required>
                                <span class="absolute right-3 top-2 text-slate-400 text-xs font-bold">Pack</span>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 rounded-lg shadow transition-all mt-2">
                        Simpan Data
                    </button>
                </form>
            </div>
        </div>

        
        <div class="lg:col-span-2">
            <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-sm text-slate-600">
                        <thead class="bg-slate-50 border-b border-slate-200 text-xs uppercase text-slate-500 font-bold">
                            <tr>
                                <th class="px-4 py-3">Tanggal & Admin</th>
                                <th class="px-4 py-3">Nama Toko</th>
                                <th class="px-4 py-3 text-center">Stok 2.5 Kg</th>
                                <th class="px-4 py-3 text-center">Stok 5 Kg</th>
                                <th class="px-4 py-3 text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            <?php $__empty_1 = true; $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-slate-50">
                                <td class="px-4 py-3">
                                    <div class="font-bold text-slate-800"><?php echo e(\Carbon\Carbon::parse($stock->tanggal)->format('d/m/Y')); ?></div>
                                    <div class="text-[10px] text-slate-500"><i class="fas fa-user mr-1"></i> <?php echo e($stock->nama_admin); ?></div>
                                </td>
                                <td class="px-4 py-3 font-medium text-slate-700">
                                    <?php echo e($stock->nama_toko); ?>

                                </td>
                                <td class="px-4 py-3 text-center">
                                    <span class="bg-emerald-50 text-emerald-600 px-2 py-1 rounded font-bold text-xs">
                                        <?php echo e(number_format($stock->stok_2_5kg, 0, ',', '.')); ?> Pack
                                    </span>
                                </td>
                                <td class="px-4 py-3 text-center">
                                    <span class="bg-blue-50 text-blue-600 px-2 py-1 rounded font-bold text-xs">
                                        <?php echo e(number_format($stock->stok_5kg, 0, ',', '.')); ?> Pack
                                    </span>
                                </td>
                                <td class="px-4 py-3 text-center">
                                    <form action="<?php echo e(route('eco.store-rice-stocks.destroy', $stock->id)); ?>" method="POST" onsubmit="return confirm('Hapus data stok toko ini?');">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-500 hover:text-red-700 bg-red-50 hover:bg-red-100 p-1.5 rounded">
                                            <i class="fas fa-trash text-xs"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center py-8 text-slate-400">Belum ada data stok beras toko.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH C:\Users\JUMPER\Downloads\Company Syafa Fiks\Company Syafa Fiks\resources\views/eco/operasional/store-rice-stock/index.blade.php ENDPATH**/ ?>