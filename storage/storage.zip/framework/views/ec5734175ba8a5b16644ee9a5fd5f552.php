<?php if (isset($component)) { $__componentOriginal58c831a7c3cbf004f2e66a23aed50e5b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal58c831a7c3cbf004f2e66a23aed50e5b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.public-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 bg-slate-50 min-h-screen">
        <div class="container mx-auto px-6">
            
            
            <div class="mb-8 flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-wider">
                <a href="<?php echo e(url('/')); ?>" class="hover:text-blue-600">Beranda</a>
                <i class="fas fa-chevron-right text-[10px]"></i>
                <a href="<?php echo e(route('components.berita')); ?>" class="hover:text-blue-600">Berita</a>
                <i class="fas fa-chevron-right text-[10px]"></i>
                <span class="text-slate-600 line-clamp-1"><?php echo e($item->judul); ?></span>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-10">
                
                
                <div class="lg:col-span-2">
                    <article class="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden p-6 md:p-10">
                        
                        
                        <div class="mb-6 pb-6 border-b border-slate-100">
                            <h1 class="text-2xl md:text-4xl font-black text-slate-800 leading-tight mb-4"><?php echo e($item->judul); ?></h1>
                            <div class="flex items-center gap-6 text-sm text-slate-500">
                                <div class="flex items-center gap-2">
                                    <i class="far fa-calendar-alt text-blue-500"></i>
                                    <?php echo e(\Carbon\Carbon::parse($item->tanggal_publish)->translatedFormat('d F Y')); ?>

                                </div>
                                <div class="flex items-center gap-2">
                                    <i class="far fa-user text-blue-500"></i>
                                    <?php echo e($item->penulis ?? 'Tim Redaksi'); ?>

                                </div>
                            </div>
                        </div>

                        
                        <?php if($item->gambar): ?>
                            <div class="w-full h-[300px] md:h-[400px] rounded-2xl overflow-hidden mb-8 bg-slate-100">
                                <img src="<?php echo e($item->gambar); ?>" class="w-full h-full object-cover">
                            </div>
                        <?php endif; ?>

                        
                        <div class="prose prose-lg prose-slate max-w-none text-slate-600 leading-loose">
                            
                            <?php echo nl2br(e($item->isi)); ?> 
                        </div>

                       
                        <div class="mt-10 pt-8 border-t border-slate-100 flex justify-between items-center">
                            <a href="<?php echo e(route('components.berita')); ?>" class="inline-flex items-center gap-2 font-bold text-slate-500 hover:text-blue-600 transition-colors">
                                <i class="fas fa-arrow-left"></i> Kembali ke Daftar
                            </a>
                            
                            <div class="flex gap-2">
                                <span class="text-xs font-bold text-slate-400 self-center mr-2 hidden md:block"></span>

                                
                                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(url()->current())); ?>" 
                                   target="_blank"
                                   class="w-8 h-8 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center hover:bg-[#1877F2] hover:text-white transition-all transform hover:-translate-y-1"
                                   title="Kunjungi Facebook Kami">
                                    <i class="fab fa-facebook-f"></i>
                                </a>

                                
                                <a href="https://www.instagram.com/syafagroup_official/" 
                                   target="_blank"
                                   class="w-8 h-8 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center hover:bg-[#E4405F] hover:text-white transition-all transform hover:-translate-y-1"
                                   title="Kunjungi Instagram Kami">
                                    <i class="fab fa-instagram"></i>
                                </a>

                                
                                <a href="https://wa.me/?text=<?php echo e(urlencode($item->judul . ' - ' . url()->current())); ?>" 
                                   target="_blank"
                                   class="w-8 h-8 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center hover:bg-[#25D366] hover:text-white transition-all transform hover:-translate-y-1"
                                   title="Hubungi Via WhatsApp">
                                    <i class="fab fa-whatsapp"></i>
                                </a>
                            </div>
                        </div>
                    </article>
                </div>

                
                <div class="lg:col-span-1 space-y-8">
                    
                    
                    <div class="bg-white rounded-3xl shadow-sm border border-slate-100 p-6 md:p-8">
                        <h3 class="text-lg font-black text-slate-800 mb-6 flex items-center gap-2">
                            <span class="w-1 h-6 bg-blue-600 rounded-full"></span> Berita Terbaru
                        </h3>
                        
                        <div class="space-y-6">
                            <?php $__empty_1 = true; $__currentLoopData = $terbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <a href="<?php echo e(route('components.berita.detail', $news->id_berita)); ?>" class="flex gap-4 group">
                                    <div class="w-20 h-20 rounded-xl overflow-hidden bg-slate-100 shrink-0">
                                        <?php if($news->gambar): ?>
                                            <img src="<?php echo e($news->gambar); ?>" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                                        <?php else: ?>
                                            <div class="w-full h-full flex items-center justify-center text-slate-300"><i class="fas fa-image"></i></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex-1">
                                        <h4 class="font-bold text-slate-700 text-sm line-clamp-2 mb-1 group-hover:text-blue-600 transition-colors">
                                            <?php echo e($news->judul); ?>

                                        </h4>
                                        <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wide">
                                            <?php echo e(\Carbon\Carbon::parse($news->tanggal_publish)->format('d M Y')); ?>

                                        </span>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-sm text-slate-400 italic">Tidak ada berita lain.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    
                    <div class="bg-blue-600 rounded-3xl shadow-lg p-8 text-white text-center relative overflow-hidden">
                        <div class="absolute top-0 right-0 -mr-8 -mt-8 w-32 h-32 bg-white/10 rounded-full blur-2xl"></div>
                        <h3 class="text-xl font-black mb-2 relative z-10">Butuh Informasi Proyek?</h3>
                        <p class="text-blue-100 text-sm mb-6 relative z-10">Hubungi kami untuk konsultasi dan detil lengkap.</p>
                        <a href="#" class="inline-block w-full bg-white text-blue-600 font-bold py-3 rounded-xl hover:bg-blue-50 transition-colors relative z-10">
                            <i class="fab fa-whatsapp mr-1"></i> 089515425734
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal58c831a7c3cbf004f2e66a23aed50e5b)): ?>
<?php $attributes = $__attributesOriginal58c831a7c3cbf004f2e66a23aed50e5b; ?>
<?php unset($__attributesOriginal58c831a7c3cbf004f2e66a23aed50e5b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal58c831a7c3cbf004f2e66a23aed50e5b)): ?>
<?php $component = $__componentOriginal58c831a7c3cbf004f2e66a23aed50e5b; ?>
<?php unset($__componentOriginal58c831a7c3cbf004f2e66a23aed50e5b); ?>
<?php endif; ?><?php /**PATH C:\Users\JUMPER\Downloads\Company Syafa Fiks\Company Syafa Fiks\resources\views/components/berita-detail.blade.php ENDPATH**/ ?>