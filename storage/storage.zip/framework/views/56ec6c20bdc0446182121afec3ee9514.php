<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

    
    <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4 animate__animated animate__fadeInDown">
        <div>
            <h2 class="text-3xl font-black text-slate-800 tracking-tight">Dashboard Overview</h2>
            <p class="text-slate-500 font-medium">Ringkasan aktivitas proyek hari ini, <?php echo e(date('d M Y')); ?></p>
        </div>
        <div class="flex gap-3">
            
            
           <a href="<?php echo e(route('admin.reports.export')); ?>" ... > 
   <i class="fas fa-print"></i> Cetak Laporan Proyek
</a>
        </div>
    </div>

    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        
        
        <div class="group bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-xl hover:border-blue-200 transition-all duration-300 relative overflow-hidden">
            <div class="absolute top-0 right-0 w-24 h-24 bg-blue-50 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
            
            <div class="relative z-10 flex items-center gap-5">
                <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-600 text-white flex items-center justify-center text-2xl shadow-lg shadow-blue-500/20 group-hover:rotate-6 transition-transform">
                    <i class="fas fa-user-tie"></i>
                </div>
                <div>
                    <p class="text-slate-500 text-xs font-bold uppercase tracking-wider mb-1">Manager Internal </p>
                    <h3 class="text-3xl font-black text-slate-800"><?php echo e($subkonPT ?? 0); ?></h3>
                    <p class="text-xs text-green-500 font-bold mt-1 flex items-center gap-1">
                        <i class="fas fa-arrow-up"></i> Aktif Bekerja
                    </p>
                </div>
            </div>
        </div>

        
        <div class="group bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-xl hover:border-orange-200 transition-all duration-300 relative overflow-hidden">
            <div class="absolute top-0 right-0 w-24 h-24 bg-orange-50 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
            
            <div class="relative z-10 flex items-center gap-5">
                <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-orange-500 to-orange-600 text-white flex items-center justify-center text-2xl shadow-lg shadow-orange-500/20 group-hover:rotate-6 transition-transform">
                    <i class="fas fa-helmet-safety"></i>
                </div>
                <div>
                    <p class="text-slate-500 text-xs font-bold uppercase tracking-wider mb-1">Subkon </p>
                    <h3 class="text-3xl font-black text-slate-800"><?php echo e($subkonEks ?? 0); ?></h3>
                    <p class="text-xs text-orange-500 font-bold mt-1 flex items-center gap-1">
                        <i class="fas fa-clock"></i> Terdaftar
                    </p>
                </div>
            </div>
        </div>

        
        <div class="group bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-xl hover:border-emerald-200 transition-all duration-300 relative overflow-hidden">
            <div class="absolute top-0 right-0 w-24 h-24 bg-emerald-50 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
            
            <div class="relative z-10 flex items-center gap-5">
                <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500 to-emerald-600 text-white flex items-center justify-center text-2xl shadow-lg shadow-emerald-500/20 group-hover:rotate-6 transition-transform">
                    <i class="fas fa-building"></i>
                </div>
                <div>
                    <p class="text-slate-500 text-xs font-bold uppercase tracking-wider mb-1">Proyek Berjalan</p>
                    <h3 class="text-3xl font-black text-slate-800"><?php echo e($projects ?? 0); ?></h3>
                    <p class="text-xs text-emerald-500 font-bold mt-1 flex items-center gap-1">
                        <i class="fas fa-check-circle"></i> On Track
                    </p>
                </div>
            </div>
        </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        
        <div class="lg:col-span-2 bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
            <div class="flex justify-between items-center mb-6">
                <h3 class="font-bold text-slate-800 text-lg">Statistik Laporan Masuk</h3>
                <select class="bg-slate-50 border-none text-xs font-bold text-slate-500 rounded-lg py-1 px-3 focus:ring-0 cursor-pointer hover:bg-slate-100">
                    <option>7 Hari Terakhir</option>
                    <option>Bulan Ini</option>
                </select>
            </div>
            
            <div id="chart"></div>
        </div>

        
        <div class="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
            <h3 class="font-bold text-slate-800 text-lg mb-6">Aktivitas Terbaru</h3>
            
            <div class="relative border-l-2 border-slate-100 ml-3 space-y-6">
                
                
                <div class="ml-6 relative">
                    <div class="absolute -left-[31px] bg-blue-500 h-4 w-4 rounded-full border-4 border-white shadow-sm"></div>
                    <h4 class="text-sm font-bold text-slate-800">Proyek Baru Dibuat</h4>
                    <p class="text-xs text-slate-500 mt-1">Admin menambahkan proyek "Renovasi Gedung A"</p>
                    <span class="text-[10px] font-bold text-slate-400 mt-2 block">2 Jam yang lalu</span>
                </div>

                
                <div class="ml-6 relative">
                    <div class="absolute -left-[31px] bg-emerald-500 h-4 w-4 rounded-full border-4 border-white shadow-sm"></div>
                    <h4 class="text-sm font-bold text-slate-800">Laporan Diterima</h4>
                    <p class="text-xs text-slate-500 mt-1">Subkon PT memverifikasi laporan dari Vendor B</p>
                    <span class="text-[10px] font-bold text-slate-400 mt-2 block">5 Jam yang lalu</span>
                </div>

                
                <div class="ml-6 relative">
                    <div class="absolute -left-[31px] bg-orange-400 h-4 w-4 rounded-full border-4 border-white shadow-sm"></div>
                    <h4 class="text-sm font-bold text-slate-800">User Baru Mendaftar</h4>
                    <p class="text-xs text-slate-500 mt-1">Subkon Eksternal baru telah ditambahkan</p>
                    <span class="text-[10px] font-bold text-slate-400 mt-2 block">1 Hari yang lalu</span>
                </div>
            </div>
            
            <button class="w-full mt-6 py-2 text-xs font-bold text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                Lihat Semua Aktivitas
            </button>
        </div>
    </div>

    
    <script>
        function printDashboard() {
            window.print();
        }

        document.addEventListener('DOMContentLoaded', function () {
            // 1. SweetAlert Welcome Toast
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            });

            Toast.fire({
                icon: 'success',
                title: 'Selamat Datang Kembali, Admin!'
            });

            // 2. ApexCharts Configuration
            var options = {
                series: [{
                    name: 'Laporan Masuk',
                    data: [3, 4, 2, 5, 8, 6, 9] // Data Dummy
                }, {
                    name: 'Proyek Selesai',
                    data: [1, 2, 0, 1, 3, 2, 4] // Data Dummy
                }],
                chart: {
                    height: 300,
                    type: 'area',
                    fontFamily: 'Plus Jakarta Sans, sans-serif',
                    toolbar: { show: false },
                    zoom: { enabled: false }
                },
                colors: ['#3b82f6', '#10b981'],
                dataLabels: { enabled: false },
                stroke: { curve: 'smooth', width: 2 },
                fill: {
                    type: 'gradient',
                    gradient: {
                        shadeIntensity: 1,
                        opacityFrom: 0.4,
                        opacityTo: 0.05,
                        stops: [0, 100]
                    }
                },
                xaxis: {
                    categories: ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'],
                    axisBorder: { show: false },
                    axisTicks: { show: false }
                },
                yaxis: { show: false },
                grid: {
                    show: true,
                    borderColor: '#f1f5f9',
                    strokeDashArray: 4,
                }
            };

            var chart = new ApexCharts(document.querySelector("#chart"), options);
            chart.render();
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?><?php /**PATH C:\Users\Chaps\Company Syafa Fiks\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>