<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
            <h2 class="text-2xl font-black text-slate-800">Laporan Kinerja Pegawai (LHKP)</h2>
            <p class="text-sm text-slate-500">Input dan kelola laporan harian aktivitas pegawai.</p>
        </div>
    </div>

    
    <?php if(session('success')): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil',
                    text: "<?php echo e(session('success')); ?>",
                    showConfirmButton: false,
                    timer: 2000,
                    customClass: { popup: 'rounded-2xl' }
                });
            });
        </script>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        
        <div class="lg:col-span-1">
            <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 sticky top-24">
                <h3 class="font-bold text-slate-800 mb-4 pb-3 border-b border-slate-100 flex items-center gap-2">
                    <i class="fas fa-plus-circle text-emerald-500"></i> Input Laporan Baru
                </h3>

                <form action="<?php echo e(route('eco.lhkp.store')); ?>" method="POST" class="space-y-4">
                    <?php echo csrf_field(); ?>
                    
                    
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Tanggal</label>
                        <input type="date" name="tanggal" value="<?php echo e(date('Y-m-d')); ?>" class="w-full px-4 py-2 border border-slate-200 rounded-xl text-sm focus:ring-emerald-500 focus:border-emerald-500 transition-all" required>
                    </div>

                    
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Tempat / Lokasi</label>
                        <input type="text" name="tempat" class="w-full px-4 py-2 border border-slate-200 rounded-xl text-sm focus:ring-emerald-500 focus:border-emerald-500 transition-all" placeholder="Contoh: Gudang Pusat..." required>
                    </div>

                    
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Nama Pegawai</label>
                        <input type="text" name="nama_pegawai" class="w-full px-4 py-2 border border-slate-200 rounded-xl text-sm focus:ring-emerald-500 focus:border-emerald-500 transition-all" placeholder="Nama lengkap pegawai" required>
                    </div>

                    
                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block text-xs font-bold text-slate-500 uppercase mb-1">NIP</label>
                            <input type="text" name="nip" class="w-full px-4 py-2 border border-slate-200 rounded-xl text-sm focus:ring-emerald-500 focus:border-emerald-500 transition-all" placeholder="Nomor Induk" required>
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Divisi</label>
                            <input type="text" name="divisi" class="w-full px-4 py-2 border border-slate-200 rounded-xl text-sm focus:ring-emerald-500 focus:border-emerald-500 transition-all" placeholder="Contoh: Logistik" required>
                        </div>
                    </div>

                    
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Progres Pekerjaan</label>
                        <textarea name="progres_pekerjaan" rows="4" class="w-full px-4 py-2 border border-slate-200 rounded-xl text-sm focus:ring-emerald-500 focus:border-emerald-500 transition-all" placeholder="Detail pekerjaan hari ini..." required></textarea>
                    </div>

                    <button type="submit" class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 rounded-xl shadow-lg shadow-emerald-500/30 transition-all flex items-center justify-center gap-2 transform hover:-translate-y-0.5">
                        <i class="fas fa-save"></i> Simpan Data
                    </button>
                </form>
            </div>
        </div>

        
        <div class="lg:col-span-2">
            <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                <div class="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                    <h3 class="font-bold text-slate-800">Riwayat LHKP</h3>
                    <span class="text-xs font-medium bg-white border border-slate-200 text-slate-500 px-3 py-1 rounded-full"><?php echo e($lhkps->count()); ?> Data</span>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-sm text-slate-600">
                        <thead class="bg-white border-b border-slate-200 text-xs uppercase font-bold text-slate-500">
                            <tr>
                                <th class="px-6 py-4">Tanggal & Lokasi</th>
                                <th class="px-6 py-4">Pegawai</th>
                                <th class="px-6 py-4">Ringkasan Progres</th>
                                <th class="px-6 py-4 text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 bg-white">
                            <?php $__empty_1 = true; $__currentLoopData = $lhkps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lhkp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-slate-50 transition-colors group">
                                <td class="px-6 py-4 align-top">
                                    <div class="font-bold text-slate-800"><?php echo e(\Carbon\Carbon::parse($lhkp->tanggal)->format('d/m/Y')); ?></div>
                                    <div class="text-xs text-slate-500 mt-1 flex items-center gap-1">
                                        <i class="fas fa-map-pin text-red-400"></i> <?php echo e($lhkp->tempat); ?>

                                    </div>
                                </td>
                                <td class="px-6 py-4 align-top">
                                    <div class="font-bold text-emerald-700"><?php echo e($lhkp->nama_pegawai); ?></div>
                                    <div class="text-xs text-slate-400">NIP: <?php echo e($lhkp->nip); ?></div>
                                    <span class="inline-block mt-1 px-2 py-0.5 bg-slate-100 text-slate-500 text-[10px] rounded border border-slate-200">
                                        <?php echo e($lhkp->divisi); ?>

                                    </span>
                                </td>
                                <td class="px-6 py-4 align-top">
                                    <p class="line-clamp-2 text-xs leading-relaxed text-slate-600" title="<?php echo e($lhkp->progres_pekerjaan); ?>">
                                        <?php echo e($lhkp->progres_pekerjaan); ?>

                                    </p>
                                </td>
                                <td class="px-6 py-4 align-top text-center">
                                    <div class="flex items-center justify-center gap-2 opacity-60 group-hover:opacity-100 transition-opacity">
                                        
                                        <button x-data @click="$dispatch('open-modal', 'edit-modal-<?php echo e($lhkp->id); ?>')" 
                                            class="w-8 h-8 flex items-center justify-center rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white transition-all border border-blue-100" 
                                            title="Edit">
                                            <i class="fas fa-pen text-xs"></i>
                                        </button>

                                        
                                        <button type="button" onclick="confirmDelete('<?php echo e($lhkp->id); ?>')" 
                                            class="w-8 h-8 flex items-center justify-center rounded-lg bg-red-50 text-red-600 hover:bg-red-600 hover:text-white transition-all border border-red-100" 
                                            title="Hapus">
                                            <i class="fas fa-trash text-xs"></i>
                                        </button>
                                        
                                        <form id="delete-form-<?php echo e($lhkp->id); ?>" action="<?php echo e(route('eco.lhkp.destroy', $lhkp->id)); ?>" method="POST" class="hidden">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        </form>
                                    </div>
                                </td>
                            </tr>

                            
                            <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'edit-modal-'.e($lhkp->id).'','focusable' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'edit-modal-'.e($lhkp->id).'','focusable' => true]); ?>
                                <form method="POST" action="<?php echo e(route('eco.lhkp.update', $lhkp->id)); ?>" class="bg-white rounded-2xl overflow-hidden flex flex-col max-h-[90vh]">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                    
                                    
                                    <div class="bg-slate-50 px-6 py-4 border-b border-slate-100 flex justify-between items-center">
                                        <h3 class="text-lg font-bold text-slate-800">Edit Laporan Kinerja</h3>
                                        <button type="button" x-on:click="$dispatch('close')" class="text-slate-400 hover:text-slate-600">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>

                                    
                                    <div class="p-6 overflow-y-auto custom-scrollbar space-y-4">
                                        <div class="grid grid-cols-2 gap-4">
                                            <div>
                                                <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Tanggal</label>
                                                <input type="date" name="tanggal" value="<?php echo e($lhkp->tanggal); ?>" class="w-full px-4 py-2 border border-slate-200 rounded-xl text-sm focus:ring-blue-500" required>
                                            </div>
                                            <div>
                                                <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Tempat</label>
                                                <input type="text" name="tempat" value="<?php echo e($lhkp->tempat); ?>" class="w-full px-4 py-2 border border-slate-200 rounded-xl text-sm focus:ring-blue-500" required>
                                            </div>
                                        </div>

                                        <div>
                                            <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Nama Pegawai</label>
                                            <input type="text" name="nama_pegawai" value="<?php echo e($lhkp->nama_pegawai); ?>" class="w-full px-4 py-2 border border-slate-200 rounded-xl text-sm focus:ring-blue-500" required>
                                        </div>

                                        <div class="grid grid-cols-2 gap-4">
                                            <div>
                                                <label class="block text-xs font-bold text-slate-500 uppercase mb-1">NIP</label>
                                                <input type="text" name="nip" value="<?php echo e($lhkp->nip); ?>" class="w-full px-4 py-2 border border-slate-200 rounded-xl text-sm focus:ring-blue-500" required>
                                            </div>
                                            <div>
                                                <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Divisi</label>
                                                <input type="text" name="divisi" value="<?php echo e($lhkp->divisi); ?>" class="w-full px-4 py-2 border border-slate-200 rounded-xl text-sm focus:ring-blue-500" required>
                                            </div>
                                        </div>

                                        <div>
                                            <label class="block text-xs font-bold text-slate-500 uppercase mb-1">Progres Pekerjaan</label>
                                            <textarea name="progres_pekerjaan" rows="5" class="w-full px-4 py-2 border border-slate-200 rounded-xl text-sm focus:ring-blue-500" required><?php echo e($lhkp->progres_pekerjaan); ?></textarea>
                                        </div>
                                    </div>

                                    
                                    <div class="px-6 py-4 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
                                        <button type="button" x-on:click="$dispatch('close')" class="px-4 py-2 bg-white border border-slate-200 text-slate-600 rounded-lg text-sm font-bold hover:bg-slate-50">Batal</button>
                                        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-bold hover:bg-blue-700 shadow-lg shadow-blue-500/30">Simpan Perubahan</button>
                                    </div>
                                </form>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="px-6 py-12 text-center text-slate-400">
                                    <div class="flex flex-col items-center justify-center">
                                        <i class="far fa-folder-open text-4xl mb-3 text-slate-300"></i>
                                        <p>Belum ada data laporan kinerja.</p>
                                    </div>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    
    <script>
        function confirmDelete(id) {
            Swal.fire({
                title: 'Hapus Laporan?',
                text: "Data yang dihapus tidak dapat dikembalikan!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#cbd5e1',
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal',
                customClass: { popup: 'rounded-2xl' }
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('delete-form-' + id).submit();
                }
            })
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?><?php /**PATH C:\Users\JUMPER\Downloads\Company Syafa Fiks\Company Syafa Fiks\resources\views/eco/lhkp/index.blade.php ENDPATH**/ ?>