<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use App\Models\EcoLocation;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    public function index()
    {
        $users = User::latest()->get();
        // Mengambil data lokasi/cabang yang aktif saja (atau semua, sesuai kebutuhan)
        $locations = EcoLocation::where('status', 'active')->get(); 
        
        return view('admin.users.index', compact('users', 'locations'));
    }

    public function store(Request $request)
    {
        // 1. PERBAIKAN VALIDASI (Penambahan Role Baru: manager_wilayah)
        $request->validate([
            'name' => 'required|string|max:255',
            // Ganti 'email' menjadi 'string' agar NIP/NIB bisa masuk (tanpa @)
            'email' => 'required|string|max:255|unique:users', 
            'role' => 'required|in:admin,subkon_pt,subkon_eks,eco,indie,keuangan,kepala_kantor,manager_unit,manager_wilayah,keuangan_eco,keuangan_indie',
            'password' => 'required|string|min:8',
        ]);

        // 2. PERBAIKAN SIMPAN DATA (Hapus specialization, Tambah wilayah)
        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => $request->role,
            'company_name' => $request->company_name,
            'wilayah' => $request->wilayah, // <--- Kolom Wilayah Ditambahkan
            'phone' => $request->phone,
        ]);

        return redirect()->back()->with('success', 'Pengguna berhasil ditambahkan!');
    }

    public function update(Request $request, $id)
    {
        $user = User::findOrFail($id);

        // Validasi Role Baru saat Update
        $request->validate([
            'name' => 'required|string|max:255',
            // Hapus validasi 'email', ganti string
            'email' => ['required', 'string', Rule::unique('users')->ignore($user->id)],
            'role' => 'required|in:admin,subkon_pt,subkon_eks,eco,indie,keuangan,kepala_kantor,manager_unit,manager_wilayah,keuangan_eco,keuangan_indie',
        ]);

        $data = [
            'name' => $request->name,
            'email' => $request->email,
            'role' => $request->role,
            'company_name' => $request->company_name,
            'wilayah' => $request->wilayah, // <--- Kolom Wilayah Ditambahkan
            'phone' => $request->phone,
        ];

        // Jika password diisi, maka update password
        if ($request->filled('password')) {
            $data['password'] = Hash::make($request->password);
        }

        $user->update($data);

        return redirect()->back()->with('success', 'Data pengguna berhasil diperbarui!');
    }

    public function destroy($id)
    {
        $user = User::findOrFail($id);
        $user->delete();
        return redirect()->back()->with('success', 'Pengguna berhasil dihapus!');
    }
}