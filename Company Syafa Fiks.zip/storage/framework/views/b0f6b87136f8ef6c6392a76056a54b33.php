<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex flex-col md:flex-row justify-between items-center mb-6 gap-4 animate__animated animate__fadeInDown">
        <div>
            <h2 class="text-2xl font-black text-slate-800">Global Login History</h2>
            <p class="text-slate-500 text-sm">Memantau aktivitas login seluruh pengguna sistem.</p>
        </div>
        
        
        <div class="flex gap-3">
            <div class="bg-blue-50 px-4 py-2 rounded-xl border border-blue-100 text-center">
                <span class="block text-xs font-bold text-blue-400 uppercase">Total Log</span>
                <span class="font-black text-lg text-blue-700"><?php echo e($histories->total()); ?></span>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden animate__animated animate__fadeInUp">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm text-slate-600">
                <thead class="bg-slate-50 border-b border-slate-200 text-xs uppercase font-bold text-slate-500 tracking-wider">
                    <tr>
                        <th class="px-6 py-4">Pengguna</th>
                        <th class="px-6 py-4">Waktu Login</th>
                        <th class="px-6 py-4">IP Address</th>
                        <th class="px-6 py-4">Perangkat</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-slate-50 transition-colors group">
                        
                        
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-3">
                                
                                <div class="w-9 h-9 rounded-full flex items-center justify-center font-bold text-xs shadow-sm
                                    <?php if($history->user->role == 'admin'): ?> bg-purple-600 text-white
                                    <?php elseif($history->user->role == 'subkon_pt'): ?> bg-blue-600 text-white
                                    <?php else: ?> bg-emerald-500 text-white <?php endif; ?>">
                                    <?php echo e(substr($history->user->name, 0, 1)); ?>

                                </div>
                                
                                <div>
                                    <div class="font-bold text-slate-800 group-hover:text-blue-600 transition-colors">
                                        <?php echo e($history->user->name); ?>

                                    </div>
                                    <div class="flex items-center gap-2">
                                        
                                        <span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider
                                            <?php if($history->user->role == 'admin'): ?> bg-purple-50 text-purple-700 border border-purple-100
                                            <?php elseif($history->user->role == 'subkon_pt'): ?> bg-blue-50 text-blue-700 border border-blue-100
                                            <?php else: ?> bg-emerald-50 text-emerald-700 border border-emerald-100 <?php endif; ?>">
                                            <?php echo e(str_replace('_', ' ', $history->user->role)); ?>

                                        </span>
                                        <span class="text-xs text-slate-400 hidden md:inline">| <?php echo e($history->user->email); ?></span>
                                    </div>
                                </div>
                            </div>
                        </td>

                        
                        <td class="px-6 py-4">
                            <div class="flex flex-col">
                                <span class="font-bold text-slate-700">
                                    <?php echo e(\Carbon\Carbon::parse($history->login_at)->translatedFormat('d M Y')); ?>

                                </span>
                                <span class="text-xs text-slate-400 font-mono">
                                    <?php echo e(\Carbon\Carbon::parse($history->login_at)->format('H:i:s')); ?> WIB
                                </span>
                            </div>
                        </td>

                        
                        <td class="px-6 py-4">
                            <span class="font-mono text-xs font-semibold bg-slate-100 px-2 py-1 rounded text-slate-600 border border-slate-200">
                                <?php echo e($history->ip_address); ?>

                            </span>
                        </td>

                        
                        <td class="px-6 py-4">
                            <div class="max-w-[200px] truncate text-xs text-slate-500" title="<?php echo e($history->user_agent); ?>">
                                <?php if(Str::contains($history->user_agent, 'Mobile')): ?>
                                    <i class="fas fa-mobile-alt mr-1"></i> Mobile
                                <?php else: ?>
                                    <i class="fas fa-desktop mr-1"></i> Desktop
                                <?php endif; ?>
                                <span class="opacity-70">- <?php echo e(Str::limit($history->user_agent, 20)); ?></span>
                            </div>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="px-6 py-12 text-center">
                            <div class="flex flex-col items-center justify-center text-slate-400">
                                <i class="fas fa-history text-4xl mb-3 opacity-30"></i>
                                <span class="text-sm">Belum ada data riwayat login.</span>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        
        <div class="px-6 py-4 border-t border-slate-100 bg-slate-50">
            <?php echo e($histories->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?><?php /**PATH C:\Users\Chaps\Company Syafa Fiks\resources\views/login-history/index.blade.php ENDPATH**/ ?>