<?php $__env->startSection('content'); ?>


<section class="relative bg-gradient-to-br from-sky-500 via-blue-600 to-sky-700 text-white min-h-screen flex items-center justify-center overflow-hidden">
    
    <div class="absolute inset-0 z-0">
        <div class="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%23ffffff\' fill-opacity=\'0.1\'%3E%3Cpath d=\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-30"></div>
        <div class="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-slate-50/20"></div>
    </div>

    
    <div class="absolute top-20 left-10 w-32 h-32 bg-white/20 rounded-full blur-2xl opacity-40 animate-pulse"></div>
    <div class="absolute bottom-20 right-10 w-48 h-48 bg-sky-300/20 rounded-full blur-3xl opacity-40 animate-pulse" style="animation-delay: 1s;"></div>

    <div class="container mx-auto px-6 text-center relative z-10">
        
        
        <div class="mt-12 mb-10 flex justify-center">
            <div class="relative group">
                <div class="w-28 h-28 md:w-36 md:h-36 bg-white rounded-3xl flex items-center justify-center shadow-2xl transform group-hover:rotate-3 transition-transform duration-500">
                    <i class="fa-solid fa-layer-group text-6xl md:text-7xl text-blue-600"></i>
                </div>
                <div class="absolute -inset-4 bg-white/30 rounded-full blur-xl opacity-0 group-hover:opacity-50 transition-all duration-500"></div>
            </div>
        </div>

        
        <h1 class="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black mb-6 tracking-tight leading-tight animate-fade-in-up drop-shadow-md">
            SYAFA <span class="text-sky-200">GROUP</span>
        </h1>

        
        <p class="text-lg sm:text-xl md:text-2xl text-sky-100 mb-10 max-w-3xl mx-auto font-light leading-relaxed animate-fade-in-up" style="animation-delay: 0.2s;">
            Mitra strategis terpercaya dalam memberikan solusi <span class="font-semibold text-white">IT, Supplier, & Konsultasi</span> yang inovatif untuk kemajuan bisnis Anda.
        </p>

        
        <div class="flex flex-col sm:flex-row justify-center gap-4 animate-fade-in-up" style="animation-delay: 0.4s;">
            <a href="#layanan" class="group bg-white text-blue-600 text-lg font-bold py-4 px-10 rounded-full shadow-xl transition-all transform hover:-translate-y-1 hover:shadow-2xl inline-flex items-center justify-center gap-3">
                <span class="relative z-10">Layanan Kami</span>
                <i class="fa-solid fa-arrow-right text-sm group-hover:translate-x-1 transition-transform"></i>
            </a>
            <a href="#kontak" class="group bg-transparent border-2 border-white text-white text-lg font-bold py-4 px-10 rounded-full transition-all transform hover:bg-white/10 inline-flex items-center justify-center gap-3">
                <span class="relative z-10">Hubungi Kami</span>
            </a>
        </div>

        
        <div class="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16 max-w-5xl mx-auto animate-fade-in-up" style="animation-delay: 0.6s;">
            <div class="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-5 text-center hover:bg-white/20 transition-all group">
                <div class="text-3xl font-black text-white mb-1">5+</div>
                <div class="text-sm text-sky-100 font-medium">Tahun Pengalaman</div>
            </div>
            <div class="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-5 text-center hover:bg-white/20 transition-all group">
                <div class="text-3xl font-black text-white mb-1">100+</div>
                <div class="text-sm text-sky-100 font-medium">Proyek Selesai</div>
            </div>
            <div class="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-5 text-center hover:bg-white/20 transition-all group">
                <div class="text-3xl font-black text-white mb-1">50+</div>
                <div class="text-sm text-sky-100 font-medium">Klien Puas</div>
            </div>
            <div class="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-5 text-center hover:bg-white/20 transition-all group">
                <div class="text-3xl font-black text-white mb-1">24/7</div>
                <div class="text-sm text-sky-100 font-medium">Dukungan Support</div>
            </div>
        </div>
    </div>
</section>


<section id="profil" class="py-24 bg-white relative">
    <div class="container mx-auto px-6">
        <div class="flex flex-col lg:flex-row items-center gap-16">
            
            <div class="lg:w-1/2 relative">
                <div class="absolute -top-4 -left-4 w-24 h-24 bg-sky-100 rounded-full z-0"></div>
                <div class="absolute -bottom-4 -right-4 w-32 h-32 bg-blue-50 rounded-full z-0"></div>
                <div class="relative z-10 bg-gradient-to-tr from-sky-500 to-blue-600 rounded-3xl p-1 shadow-2xl rotate-2 hover:rotate-0 transition-transform duration-500">
                    <div class="bg-white rounded-[20px] overflow-hidden h-96 flex items-center justify-center">
                         <i class="fa-solid fa-building text-9xl text-sky-100"></i>
                    </div>
                </div>
            </div>

            
            <div class="lg:w-1/2">
                <div class="inline-flex items-center px-4 py-2 rounded-full bg-sky-50 text-sky-600 text-sm font-bold mb-6 border border-sky-100">
                    <i class="fas fa-user-tie mr-2"></i> Tentang Perusahaan
                </div>
                <h2 class="text-4xl font-black text-slate-800 mb-6 leading-tight">
                    Membangun Solusi <br>
                    <span class="text-sky-500">Untuk Masa Depan</span>
                </h2>
                <p class="text-lg text-slate-600 mb-6 leading-relaxed">
                    Syafa Group hadir sebagai jawaban atas kebutuhan bisnis modern yang menuntut kecepatan, ketepatan, dan efisiensi. Kami bergerak di berbagai sektor strategis untuk mendukung operasional perusahaan Anda.
                </p>
                
                <div class="space-y-4">
                    <div class="flex items-start">
                        <div class="w-10 h-10 bg-sky-100 rounded-full flex items-center justify-center mr-4 text-sky-600 mt-1">
                            <i class="fa-solid fa-check"></i>
                        </div>
                        <div>
                            <h4 class="font-bold text-slate-800">Profesional & Berintegritas</h4>
                            <p class="text-sm text-slate-500">Tim ahli yang siap bekerja dengan standar tinggi.</p>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="w-10 h-10 bg-sky-100 rounded-full flex items-center justify-center mr-4 text-sky-600 mt-1">
                            <i class="fa-solid fa-lightbulb"></i>
                        </div>
                        <div>
                            <h4 class="font-bold text-slate-800">Inovasi Berkelanjutan</h4>
                            <p class="text-sm text-slate-500">Selalu beradaptasi dengan teknologi terbaru.</p>
                        </div>
                    </div>
                </div>

                <div class="mt-8">
                    <a href="#" class="text-sky-600 font-bold hover:text-sky-700 inline-flex items-center gap-2">
                        Pelajari Selengkapnya <i class="fa-solid fa-arrow-right-long"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>


<section id="layanan" class="py-24 bg-slate-50">
    <div class="container mx-auto px-6">
        <div class="text-center mb-16">
            <h2 class="text-3xl sm:text-4xl font-black text-slate-800 mb-4">
                Layanan <span class="text-sky-500">Unggulan</span>
            </h2>
            <div class="h-1 w-20 bg-sky-500 mx-auto rounded-full"></div>
            <p class="text-slate-500 mt-4 max-w-2xl mx-auto">
                Kami menyediakan berbagai layanan terintegrasi untuk memaksimalkan potensi bisnis Anda.
            </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            <div class="bg-white p-8 rounded-2xl shadow-lg border-b-4 border-sky-500 hover:-translate-y-2 transition-transform duration-300 group">
                <div class="w-16 h-16 bg-sky-100 text-sky-600 rounded-xl flex items-center justify-center mb-6 text-2xl group-hover:bg-sky-500 group-hover:text-white transition-colors">
                    <i class="fa-solid fa-laptop-code"></i>
                </div>
                <h3 class="text-xl font-bold text-slate-800 mb-3">Property Solution</h3>
                <p class="text-slate-500 text-sm leading-relaxed">
                    Pengembangan website, aplikasi mobile, dan sistem informasi manajemen yang disesuaikan dengan kebutuhan spesifik perusahaan.
                </p>
            </div>

            
            <div class="bg-white p-8 rounded-2xl shadow-lg border-b-4 border-blue-600 hover:-translate-y-2 transition-transform duration-300 group">
                <div class="w-16 h-16 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center mb-6 text-2xl group-hover:bg-blue-600 group-hover:text-white transition-colors">
                    <i class="fa-solid fa-truck-fast"></i>
                </div>
                <h3 class="text-xl font-bold text-slate-800 mb-3">General Supplier</h3>
                <p class="text-slate-500 text-sm leading-relaxed">
                    Penyediaan barang dan kebutuhan operasional kantor, pengadaan alat tulis, elektronik, hingga kebutuhan industri.
                </p>
            </div>

            
            <div class="bg-white p-8 rounded-2xl shadow-lg border-b-4 border-sky-500 hover:-translate-y-2 transition-transform duration-300 group">
                <div class="w-16 h-16 bg-sky-100 text-sky-600 rounded-xl flex items-center justify-center mb-6 text-2xl group-hover:bg-sky-500 group-hover:text-white transition-colors">
                    <i class="fa-solid fa-handshake-simple"></i>
                </div>
                <h3 class="text-xl font-bold text-slate-800 mb-3">Konsultan Bisnis</h3>
                <p class="text-slate-500 text-sm leading-relaxed">
                    Pendampingan strategi bisnis, analisis pasar, dan manajemen risiko untuk memastikan pertumbuhan yang stabil.
                </p>
            </div>
        </div>
    </div>
</section>


<section class="py-24 bg-white border-t border-slate-100">
    <div class="container mx-auto px-6">
        <div class="flex justify-between items-end mb-12">
            <div>
                <h2 class="text-3xl font-black text-slate-800">Berita & Artikel</h2>
                <p class="text-slate-500 mt-2">Informasi terbaru seputar aktivitas Syafa Group</p>
            </div>
            <a href="#" class="hidden md:inline-flex items-center text-sky-600 font-bold hover:underline">
                Lihat Semua <i class="fa-solid fa-arrow-right ml-2"></i>
            </a>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            <article class="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-shadow border border-slate-100">
                <div class="h-48 bg-slate-200 flex items-center justify-center">
                    <i class="fa-regular fa-image text-4xl text-slate-400"></i>
                </div>
                <div class="p-6">
                    <span class="text-xs font-bold text-sky-600 uppercase tracking-wider">Project</span>
                    <h3 class="text-lg font-bold text-slate-800 mt-2 mb-3 hover:text-sky-600 cursor-pointer">Implementasi Sistem ERP di PT. Maju Jaya</h3>
                    <p class="text-slate-500 text-sm line-clamp-3">
                        Syafa Group berhasil menyelesaikan implementasi sistem Enterprise Resource Planning (ERP) untuk meningkatkan efisiensi...
                    </p>
                    <div class="mt-4 pt-4 border-t border-slate-100 flex justify-between items-center text-xs text-slate-400">
                        <span><i class="fa-regular fa-calendar mr-1"></i> 10 Jan 2026</span>
                        <a href="#" class="text-sky-600 font-semibold">Baca</a>
                    </div>
                </div>
            </article>

            
            <article class="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-shadow border border-slate-100">
                <div class="h-48 bg-slate-200 flex items-center justify-center">
                    <i class="fa-regular fa-image text-4xl text-slate-400"></i>
                </div>
                <div class="p-6">
                    <span class="text-xs font-bold text-sky-600 uppercase tracking-wider">Internal</span>
                    <h3 class="text-lg font-bold text-slate-800 mt-2 mb-3 hover:text-sky-600 cursor-pointer">Syafa Group Buka Cabang Baru di Surabaya</h3>
                    <p class="text-slate-500 text-sm line-clamp-3">
                        Guna memperluas jangkauan layanan, kami dengan bangga meresmikan kantor cabang baru yang berlokasi di...
                    </p>
                    <div class="mt-4 pt-4 border-t border-slate-100 flex justify-between items-center text-xs text-slate-400">
                        <span><i class="fa-regular fa-calendar mr-1"></i> 05 Jan 2026</span>
                        <a href="#" class="text-sky-600 font-semibold">Baca</a>
                    </div>
                </div>
            </article>

            
            <article class="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-shadow border border-slate-100">
                <div class="h-48 bg-slate-200 flex items-center justify-center">
                    <i class="fa-regular fa-image text-4xl text-slate-400"></i>
                </div>
                <div class="p-6">
                    <span class="text-xs font-bold text-sky-600 uppercase tracking-wider">Teknologi</span>
                    <h3 class="text-lg font-bold text-slate-800 mt-2 mb-3 hover:text-sky-600 cursor-pointer">Tren Teknologi Cloud Computing 2026</h3>
                    <p class="text-slate-500 text-sm line-clamp-3">
                        Menilik perkembangan teknologi awan yang semakin krusial bagi keberlangsungan bisnis di era digital...
                    </p>
                    <div class="mt-4 pt-4 border-t border-slate-100 flex justify-between items-center text-xs text-slate-400">
                        <span><i class="fa-regular fa-calendar mr-1"></i> 01 Jan 2026</span>
                        <a href="#" class="text-sky-600 font-semibold">Baca</a>
                    </div>
                </div>
            </article>
        </div>
    </div>
</section>


<section id="kontak" class="py-24 bg-gradient-to-br from-slate-900 to-blue-900 text-white relative overflow-hidden">
    
    <div class="absolute top-0 right-0 w-64 h-64 bg-sky-500 rounded-full blur-3xl opacity-20 transform translate-x-1/2 -translate-y-1/2"></div>
    <div class="absolute bottom-0 left-0 w-64 h-64 bg-blue-600 rounded-full blur-3xl opacity-20 transform -translate-x-1/2 translate-y-1/2"></div>

    <div class="container mx-auto px-6 relative z-10 text-center">
        <h2 class="text-3xl sm:text-4xl font-black mb-6">Siap Mengembangkan Bisnis Anda?</h2>
        <p class="text-sky-100 text-lg mb-10 max-w-2xl mx-auto">
            Hubungi tim Syafa Group hari ini untuk konsultasi gratis mengenai kebutuhan IT maupun pengadaan barang perusahaan Anda.
        </p>

        <div class="flex flex-col md:flex-row justify-center gap-6 mb-12">
            <a href="#" class="flex items-center justify-center gap-3 bg-white text-blue-900 px-8 py-4 rounded-full font-bold hover:bg-sky-50 transition-colors shadow-lg">
                <i class="fa-brands fa-whatsapp text-2xl"></i>
                Chat WhatsApp
            </a>
            <a href="#" class="flex items-center justify-center gap-3 bg-transparent border border-white/30 text-white px-8 py-4 rounded-full font-bold hover:bg-white/10 transition-colors">
                <i class="fa-regular fa-envelope text-xl"></i>
                Kirim Email
            </a>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto text-left">
            <div class="flex items-start p-4 rounded-xl bg-white/5 border border-white/10 backdrop-blur-sm">
                <i class="fa-solid fa-location-dot text-sky-400 mt-1 mr-4 text-xl"></i>
                <div>
                    <h4 class="font-bold text-white">Alamat</h4>
                    <p class="text-sm text-sky-200 mt-1">Jl. KH. Wahid Hasyim, Jombang, Jawa Timur</p>
                </div>
            </div>
            <div class="flex items-start p-4 rounded-xl bg-white/5 border border-white/10 backdrop-blur-sm">
                <i class="fa-solid fa-phone text-sky-400 mt-1 mr-4 text-xl"></i>
                <div>
                    <h4 class="font-bold text-white">Telepon</h4>
                    <p class="text-sm text-sky-200 mt-1">(0321) 123456</p>
                </div>
            </div>
            <div class="flex items-start p-4 rounded-xl bg-white/5 border border-white/10 backdrop-blur-sm">
                <i class="fa-solid fa-clock text-sky-400 mt-1 mr-4 text-xl"></i>
                <div>
                    <h4 class="font-bold text-white">Jam Operasional</h4>
                    <p class="text-sm text-sky-200 mt-1">Senin - Jumat: 08.00 - 16.00 WIB</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Chaps\Company tunjung namanya\resources\views/welcome.blade.php ENDPATH**/ ?>