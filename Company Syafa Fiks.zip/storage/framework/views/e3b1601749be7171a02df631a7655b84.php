<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    
    <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4 animate__animated animate__fadeInDown">
        <div>
            <h2 class="text-3xl font-black text-slate-800 tracking-tight">Manajemen Pengguna</h2>
            <p class="text-slate-500 font-medium">Kelola akun Subkon Internal (PT) dan Vendor Eksternal.</p>
        </div>
        
        <div class="flex gap-3 w-full md:w-auto">
            
            <div class="relative w-full md:w-64 group">
                <input type="text" id="searchInput" placeholder="Cari data..." 
                    class="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-blue-500 text-sm shadow-sm transition-all group-hover:border-blue-300">
                <i class="fas fa-search absolute left-3 top-3 text-slate-400 group-focus-within:text-blue-500 transition-colors"></i>
            </div>

            <button x-data @click="$dispatch('open-modal', 'add-user-modal')" 
                class="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-lg shadow-blue-500/30 transition-all flex items-center gap-2 transform hover:-translate-y-0.5">
                <i class="fas fa-plus-circle"></i> <span class="hidden md:inline">User Baru</span>
            </button>
        </div>
    </div>

    
    <?php if(session('success')): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true
                });
                Toast.fire({
                    icon: 'success',
                    title: "<?php echo e(session('success')); ?>"
                });
            });
        </script>
    <?php endif; ?>

    
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden animate__animated animate__fadeInUp">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm text-slate-600" id="userTable">
                <thead class="bg-slate-50 border-b border-slate-200 text-xs uppercase font-bold text-slate-500 tracking-wider">
                    <tr>
                        <th class="px-6 py-4">Pengguna</th>
                        <th class="px-6 py-4">Role & Perusahaan</th>
                        <th class="px-6 py-4">Kontak</th>
                        <th class="px-6 py-4">Status</th>
                        <th class="px-6 py-4 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-blue-50/50 transition-colors group">
                        
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-full bg-gradient-to-br <?php echo e($user->role == 'subkon_pt' ? 'from-blue-500 to-blue-600' : 'from-orange-400 to-orange-500'); ?> text-white flex items-center justify-center font-bold text-lg shadow-md ring-2 ring-white">
                                    <?php echo e(substr($user->name, 0, 1)); ?>

                                </div>
                                <div>
                                    <span class="font-bold text-slate-800 block"><?php echo e($user->name); ?></span>
                                    <span class="text-xs text-slate-400"><?php echo e($user->email); ?></span>
                                </div>
                            </div>
                        </td>

                        
                        <td class="px-6 py-4">
                            <div class="flex flex-col">
                                <?php if($user->role == 'subkon_pt'): ?>
                                    <span class="inline-flex items-center w-fit px-2.5 py-0.5 rounded-md text-[10px] font-bold bg-blue-100 text-blue-700 border border-blue-200 uppercase tracking-wide">
                                        INTERNAL (PT)
                                    </span>
                                <?php else: ?>
                                    <span class="inline-flex items-center w-fit px-2.5 py-0.5 rounded-md text-[10px] font-bold bg-orange-100 text-orange-700 border border-orange-200 uppercase tracking-wide">
                                        VENDOR (EKS)
                                    </span>
                                <?php endif; ?>
                                <span class="text-xs font-medium text-slate-500 mt-1 flex items-center gap-1">
                                    <i class="far fa-building"></i> <?php echo e($user->company_name ?? '-'); ?>

                                </span>
                            </div>
                        </td>

                        
                        <td class="px-6 py-4">
                            <div class="flex flex-col gap-1">
                                <span class="text-xs flex items-center gap-2"><i class="fas fa-phone w-4 text-slate-400"></i> <?php echo e($user->phone ?? '-'); ?></span>
                                <span class="text-xs flex items-center gap-2"><i class="fas fa-tools w-4 text-slate-400"></i> <?php echo e($user->specialization ?? '-'); ?></span>
                            </div>
                        </td>

                        
                        <td class="px-6 py-4">
                            <span class="inline-flex items-center gap-1.5 px-2 py-1 rounded-full bg-emerald-50 text-emerald-600 text-xs font-bold border border-emerald-100">
                                <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> Aktif
                            </span>
                        </td>

                        
                        <td class="px-6 py-4 text-center">
                            <div class="flex justify-center items-center gap-2">
                                <button x-data @click="$dispatch('open-modal', 'edit-user-modal-<?php echo e($user->id); ?>')" 
                                    class="w-8 h-8 rounded-lg bg-white border border-slate-200 text-slate-500 hover:bg-blue-600 hover:text-white hover:border-blue-600 flex items-center justify-center transition-all shadow-sm" title="Edit">
                                    <i class="fas fa-pen text-xs"></i>
                                </button>
                                
                                <button type="button" onclick="confirmDelete('<?php echo e($user->id); ?>')"
                                    class="w-8 h-8 rounded-lg bg-white border border-slate-200 text-slate-500 hover:bg-red-600 hover:text-white hover:border-red-600 flex items-center justify-center transition-all shadow-sm" title="Hapus">
                                    <i class="fas fa-trash text-xs"></i>
                                </button>
                                
                                <form id="delete-form-<?php echo e($user->id); ?>" action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" class="hidden">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                </form>
                            </div>
                        </td>
                    </tr>

                    
                    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'edit-user-modal-'.e($user->id).'','focusable' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'edit-user-modal-'.e($user->id).'','focusable' => true]); ?>
                        
                        <form method="POST" action="<?php echo e(route('admin.users.update', $user->id)); ?>" class="bg-white rounded-2xl flex flex-col max-h-[90vh] shadow-2xl">
                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

                            
                            <div class="bg-gradient-to-r from-slate-800 to-slate-900 px-8 py-5 flex justify-between items-center shrink-0 rounded-t-2xl">
                                <h2 class="text-xl font-bold text-white flex items-center gap-3">
                                    <i class="fas fa-user-edit text-blue-400"></i> Edit Data Pengguna
                                </h2>
                                <button type="button" x-on:click="$dispatch('close')" class="text-slate-400 hover:text-white transition-colors focus:outline-none">
                                    <i class="fas fa-times text-xl"></i>
                                </button>
                            </div>

                            
                            <div class="p-8 overflow-y-auto custom-scrollbar flex-1">
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    
                                    <div class="col-span-2">
                                        <label class="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">Nama Lengkap</label>
                                        <div class="relative group">
                                            <i class="fas fa-user absolute left-4 top-3.5 text-slate-400 group-focus-within:text-blue-500 transition-colors"></i>
                                            <input type="text" name="name" value="<?php echo e($user->name); ?>" class="w-full pl-12 pr-4 py-3 border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-semibold text-slate-700 bg-slate-50/50 transition-all" required>
                                        </div>
                                    </div>

                                    
                                    <div class="col-span-2">
                                        <label class="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">Email Login</label>
                                        <div class="relative group">
                                            <i class="fas fa-envelope absolute left-4 top-3.5 text-slate-400 group-focus-within:text-blue-500 transition-colors"></i>
                                            <input type="email" name="email" value="<?php echo e($user->email); ?>" class="w-full pl-12 pr-4 py-3 border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-600 bg-slate-50/50 transition-all" required>
                                        </div>
                                    </div>

                                    
                                    <div class="col-span-2 bg-amber-50/50 p-4 rounded-2xl border border-amber-100">
                                        <label class="block text-xs font-bold text-amber-700 uppercase mb-2 ml-1 flex items-center gap-2">
                                            <i class="fas fa-shield-alt"></i> Password Baru (Opsional)
                                        </label>
                                        <div class="relative group">
                                            <i class="fas fa-lock absolute left-4 top-3.5 text-amber-400 group-focus-within:text-amber-500 transition-colors"></i>
                                            <input type="text" name="password" placeholder="Isi hanya jika ingin mengganti password" class="w-full pl-12 pr-4 py-3 border-amber-200 bg-white rounded-xl text-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all placeholder:text-amber-300">
                                        </div>
                                    </div>

                                    
                                    <div>
                                        <label class="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">Role Akun</label>
                                        <div class="relative group">
                                            <i class="fas fa-id-badge absolute left-4 top-3.5 text-slate-400 group-focus-within:text-blue-500 transition-colors"></i>
                                            <select name="role" class="w-full pl-12 pr-4 py-3 border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-600 bg-slate-50/50 transition-all appearance-none">
                                                <option value="subkon_pt" <?php echo e($user->role == 'subkon_pt' ? 'selected' : ''); ?>>Subkon PT (Internal)</option>
                                                <option value="subkon_eks" <?php echo e($user->role == 'subkon_eks' ? 'selected' : ''); ?>>Subkon Vendor (Eks)</option>
                                            </select>
                                            <i class="fas fa-chevron-down absolute right-4 top-3.5 text-slate-400 pointer-events-none"></i>
                                        </div>
                                    </div>

                                    
                                    <div>
                                        <label class="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">No. Telepon</label>
                                        <div class="relative group">
                                            <i class="fas fa-phone absolute left-4 top-3.5 text-slate-400 group-focus-within:text-blue-500 transition-colors"></i>
                                            <input type="text" name="phone" value="<?php echo e($user->phone); ?>" class="w-full pl-12 pr-4 py-3 border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-600 bg-slate-50/50 transition-all">
                                        </div>
                                    </div>

                                    
                                    <div>
                                        <label class="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">Perusahaan</label>
                                        <div class="relative group">
                                            <i class="fas fa-building absolute left-4 top-3.5 text-slate-400 group-focus-within:text-blue-500 transition-colors"></i>
                                            <input type="text" name="company_name" value="<?php echo e($user->company_name); ?>" class="w-full pl-12 pr-4 py-3 border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-600 bg-slate-50/50 transition-all">
                                        </div>
                                    </div>

                                    
                                    <div>
                                        <label class="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">Spesialisasi</label>
                                        <div class="relative group">
                                            <i class="fas fa-hammer absolute left-4 top-3.5 text-slate-400 group-focus-within:text-blue-500 transition-colors"></i>
                                            <input type="text" name="specialization" value="<?php echo e($user->specialization); ?>" class="w-full pl-12 pr-4 py-3 border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-600 bg-slate-50/50 transition-all">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="px-8 py-5 border-t border-slate-100 flex justify-end gap-3 bg-white rounded-b-2xl shrink-0 z-10">
                                <button type="button" x-on:click="$dispatch('close')" class="px-5 py-2.5 bg-slate-100 text-slate-600 rounded-xl text-sm font-bold hover:bg-slate-200 transition-colors focus:outline-none">
                                    Batal
                                </button>
                                <button type="submit" class="px-6 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-bold hover:bg-blue-700 shadow-lg shadow-blue-500/20 transition-all flex items-center gap-2 transform hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                                    <i class="fas fa-save"></i> Simpan Perubahan
                                </button>
                            </div>
                        </form>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-6 py-12 text-center">
                            <div class="flex flex-col items-center justify-center text-slate-300">
                                <i class="fas fa-user-slash text-5xl mb-3"></i>
                                <p class="font-medium">Belum ada data pengguna.</p>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'add-user-modal','focusable' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'add-user-modal','focusable' => true]); ?>
        <form method="POST" action="<?php echo e(route('admin.users.store')); ?>" class="bg-white rounded-2xl flex flex-col max-h-[90vh] shadow-2xl">
            <?php echo csrf_field(); ?>
            
            
            <div class="bg-gradient-to-r from-blue-600 to-indigo-700 px-8 py-5 flex justify-between items-center shrink-0 rounded-t-2xl">
                <h2 class="text-xl font-bold text-white flex items-center gap-3">
                    <i class="fas fa-user-plus text-blue-200"></i> Tambah Pengguna Baru
                </h2>
                <button type="button" x-on:click="$dispatch('close')" class="text-blue-200 hover:text-white transition-colors focus:outline-none">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>

            
            <div class="p-8 overflow-y-auto custom-scrollbar flex-1">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    <div class="col-span-2">
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">Nama Lengkap / PT</label>
                        <div class="relative group">
                            <i class="fas fa-user absolute left-4 top-3.5 text-slate-400 group-focus-within:text-blue-500 transition-colors"></i>
                            <input type="text" name="name" class="w-full pl-12 pr-4 py-3 border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-semibold text-slate-700 bg-slate-50/50 transition-all" placeholder="Masukkan nama..." required>
                        </div>
                    </div>

                    
                    <div class="col-span-2">
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">Email Login</label>
                        <div class="relative group">
                            <i class="fas fa-envelope absolute left-4 top-3.5 text-slate-400 group-focus-within:text-blue-500 transition-colors"></i>
                            <input type="email" name="email" class="w-full pl-12 pr-4 py-3 border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-600 bg-slate-50/50 transition-all" placeholder="email@contoh.com" required>
                        </div>
                    </div>

                    
                    <div class="bg-slate-50/50 p-4 rounded-2xl border border-slate-100">
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1 flex items-center gap-2">
                            <i class="fas fa-key"></i> Password Default
                        </label>
                        <div class="relative">
                            <i class="fas fa-lock absolute left-4 top-3.5 text-slate-400"></i>
                            <input type="text" name="password" value="password123" class="w-full pl-12 pr-4 py-3 border-slate-200 bg-white rounded-xl text-sm text-slate-500 font-medium cursor-not-allowed" readonly>
                        </div>
                        <p class="text-[10px] text-slate-400 mt-2 ml-1">*Pengguna dapat menggantinya setelah login.</p>
                    </div>

                    
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">Role Akun</label>
                        <div class="relative group">
                            <i class="fas fa-id-badge absolute left-4 top-3.5 text-slate-400 group-focus-within:text-blue-500 transition-colors"></i>
                            <select name="role" class="w-full pl-12 pr-4 py-3 border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-700 bg-slate-50/50 transition-all appearance-none">
                                <option value="subkon_eks">Subkon Vendor (Eksternal)</option>
                                <option value="subkon_pt">Subkon Internal (PT)</option>
                            </select>
                            <i class="fas fa-chevron-down absolute right-4 top-3.5 text-slate-400 pointer-events-none"></i>
                        </div>
                    </div>

                    <div class="col-span-2 border-t border-slate-100 my-2 relative">
                        <span class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white px-3 text-xs text-slate-400 font-bold uppercase tracking-wider">Informasi Tambahan</span>
                    </div>

                    
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">Perusahaan</label>
                        <div class="relative group">
                            <i class="fas fa-building absolute left-4 top-3.5 text-slate-400 group-focus-within:text-blue-500 transition-colors"></i>
                            <input type="text" name="company_name" class="w-full pl-12 pr-4 py-3 border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-600 bg-slate-50/50 transition-all" placeholder="Opsional">
                        </div>
                    </div>

                    
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">No. Telepon</label>
                        <div class="relative group">
                            <i class="fas fa-phone absolute left-4 top-3.5 text-slate-400 group-focus-within:text-blue-500 transition-colors"></i>
                            <input type="text" name="phone" class="w-full pl-12 pr-4 py-3 border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-600 bg-slate-50/50 transition-all" placeholder="08...">
                        </div>
                    </div>

                    
                    <div class="col-span-2">
                        <label class="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">Spesialisasi</label>
                        <div class="relative group">
                            <i class="fas fa-hammer absolute left-4 top-3.5 text-slate-400 group-focus-within:text-blue-500 transition-colors"></i>
                            <input type="text" name="specialization" class="w-full pl-12 pr-4 py-3 border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-600 bg-slate-50/50 transition-all" placeholder="Contoh: Elektrikal, Sipil...">
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="px-8 py-5 border-t border-slate-100 flex justify-end gap-3 bg-white rounded-b-2xl shrink-0 z-10">
                <button type="button" x-on:click="$dispatch('close')" class="px-5 py-2.5 bg-slate-100 text-slate-600 rounded-xl text-sm font-bold hover:bg-slate-200 transition-colors focus:outline-none">
                    Batal
                </button>
                <button type="submit" class="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl text-sm font-bold hover:from-blue-700 hover:to-indigo-700 shadow-lg shadow-blue-500/30 transition-all flex items-center gap-2 transform hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                    <i class="fas fa-save"></i> Simpan Data
                </button>
            </div>
        </form>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>

    
    <style>
        .custom-scrollbar::-webkit-scrollbar {
            width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: #f1f5f9;
            margin-block: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }
    </style>

    <script>
        document.getElementById('searchInput').addEventListener('keyup', function() {
            let filter = this.value.toLowerCase();
            let rows = document.querySelectorAll('#userTable tbody tr');
            rows.forEach(row => {
                let text = row.innerText.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        });

        function confirmDelete(id) {
            Swal.fire({
                title: 'Hapus Pengguna?',
                text: "Data akan dihapus permanen!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#cbd5e1',
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal',
                customClass: { popup: 'rounded-2xl' }
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('delete-form-' + id).submit();
                }
            })
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?><?php /**PATH C:\Users\JUMPER\Downloads\Company tunjung namanya\Company tunjung namanya\resources\views/admin/users/index.blade.php ENDPATH**/ ?>